import sys
import os


def hex_to_binary(c):
	hex_to_binary = {'0':'0000',
					'1':'0001',
					'2':'0010',
					'3':'0011',
					'4':'0100',
					'5':'0101',
					'6':'0110',
					'7':'0111',
					'8':'1000',
					'9':'1001',
					'A':'1010',
					'B':'1011',
					'C':'1100',
					'D':'1101',
					'E':'1110',
					'F':'1111'}
				 
	binaryString = ''

	for i in range(0, len(c)):	
		#print("number:", i," letter:",c[i],"\n")
		binaryString += hex_to_binary[c[i]]

	print("The binary string is : ", binaryString)
	return binaryString

def binary_to_hex(c):
	print("binary to hex chosen")	
	
	binaryToHex = {
				'0000':'0',
				'0001':'1',
				'0010':'2',
				'0011':'3',
				'0100':'4',
				'0101':'5',
				'0110':'6',
				'0111':'7',
				'1000':'8',
				'1001':'9',
				'1010':'A',
				'1011':'B',
				'1100':'C',
				'1101':'D',
				'1110':'E',
				'1111':'F'
					}
	hexString = ''
	
	#need to seperate the binary string into 4 bits each and pad if less.
	
	remainder_Check = len(c) % 4
	print("checking the mod: ",remainder_Check)
	
	if(remainder_Check != 0):
		tempString = ''
		print("c before :", c)
		for ch in range (0, remainder_Check):
			tempString += '0'
		print("tempString is :", tempString)
		tempString += c
		c = tempString
		print("c after :", c)
		print("Check if the binary string provided a length with %4 equaling zero..... result", len(c) % 4)
	i=0
	byteString = ''
	print(" convertion from binary to hex starting.... splitting binary into bytes i is ",i)
	while i < len(c):
		r = i+4
		while i < r:
			#print("number:", i," letter:",c[i],"\n")
			byteString += c[i]
			i+=1
		#print("bytestring found :",byteString, " and the ascii for it is: ",binaryToHex.get(byteString,"(none)"))
		hexString += binaryToHex.get(byteString,"(No)")
		byteString = ''
	print("hexString is : ",hexString)
	return hexString
	
def binary_to_Ascii(b):
	
	bin_to_a = {'00100000':'(space)',
				'00100001':'!',
				'00100010':'"',
				'00100011':'#',
				'00100100':'$',
				'00100101':'%',
				'00100110':'&',
				'00100111':'\'',
				'00101000':'(',
				'00101001':')',
				'00101010':'*',
				'00101011':'+',
				'00101100':',',
				'00101101':'-',
				'00101110':'.',
				'00101111':'/',
			    '00110000':'0',
			    '00110001':'1',
			    '00110010':'2',
			    '00110011':'3',
			    '00110100':'4',
			    '00110101':'5',
			    '00110110':'6',
			    '00110111':'7',
			    '00111000':'8',
			    '00111001':'9',
			    '00111010':':',
			    '00111011':';',
			    '00111100':'<',
			    '00111101':'=',
			    '00111110':'>',
			    '00111111':'?',
				'01000000':'@',
				'01000001':'A',
			    '01000010':'B',
			    '01000011':'C',
			    '01000100':'D',
			    '01000101':'E',
			    '01000110':'F',
			    '01000111':'G',
			    '01001000':'H',
			    '01001001':'I',
			    '01001010':'J',
			    '01001011':'K',
			    '01001100':'L',
			    '01001101':'M',
			    '01001110':'N',
			    '01001111':'O',
			    '01010000':'P',
			    '01010001':'Q',
			    '01010010':'R',
			    '01010011':'S',
			    '01010100':'T',
			    '01010101':'U',
			    '01010110':'V',
			    '01010111':'W',
			    '01011000':'X',
			    '01011001':'Y',
			    '01011010':'Z',
			    '01011011':'[',
			    '01011100':'\\',
			    '01011101':']',
			    '01011110':'↑',
			    '01011111':'←',
				'01100000':'@',
			    '01100001':'a',
			    '01100010':'b',
			    '01100011':'c',
			    '01100100':'d',
			    '01100101':'e',
			    '01100110':'f',
			    '01100111':'g',
			    '01101000':'h',
			    '01101001':'i',
			    '01101010':'j',
			    '01101011':'k',
			    '01101100':'l',
			    '01101101':'m',
			    '01101110':'n',
			    '01101111':'o',
			    '01110000':'p',
			    '01110001':'q',
			    '01110010':'r',
			    '01110011':'s',
			    '01110100':'t',
			    '01110101':'u',
			    '01110110':'v',
			    '01110111':'w',
			    '01111000':'x',
			    '01111001':'y',
			    '01111010':'z',
				'00000000':'(NULL)',
				'00010000':'(datalink escape)',
				'00000001':'(Start of Heading)',
				'00000010':'(Start of Text)',
				'00000011':'(End of Text)',
				'00000100':'(End of Transmission)',
				'00000101':'(Enquiry)',
				'00000110':'(Acknowledgement)',
				'00000111':'(Bell)',
				'00001000':'(Backspace[d][e])',
				'00001001':'(Horizontal Tab[f])',
				'00001010':'(Line Feed)',
				'00001011':'(Vertical Tab)',
				'00001100':'(Form Feed)',
				'00001101':'(Carriage Return[g])',
				'00001110':'(Shift Out)',
				'00001111':'(Shift In)',
				'00010000':'(Data Link Escape)',
				'00010001':'(Device Control 1)',
				'00010010':'(Device Control 2)',
				'00010011':'(Device Control 3)',
				'00010100':'(Device Control 4)',
				'00010101':'(Negative Acknowledgement)',
				'00010110':'(Synchronous Idle)',
				'00010111':'(End of Transmission Block)',
				'00011000':'(Cancel)',
				'00011001':'(End of Medium)',
				'00011010':'(Substitute)',
				'00011011':'(Escape[i])',
				'00011100':'(File Separator)',
				'00011101':'(Group Separator)',
				'00011110':'(Record Separator)',
				'00011111':'(Unit Separator)',
				'01111111':'(Delete[k][e])'}
	
	Ascii = ''            
	byteString = ''
	i = 0
	
	remainder_Check = len(b) % 8
	print("Check if the binary string provided a length with %8 equaling zero..... result", remainder_Check)
	
	if(remainder_Check != 0):
		tempString = ''
		print("b before :", b)
		for ch in range (0, remainder_Check):
			tempString += '0'
		print("tempString is :", tempString)
		tempString += b
		b = tempString
		print("b after :", b)
		print("Check if the binary string provided a length with %8 equaling zero..... result", len(b) % 8)
		
	print("Ascii convertion starting.... splitting binary into bytes i is ",i)
	while i < len(b):
		r = i+8
		while i < r:
			#print("number:", i," letter:",b[i],"\n")
			byteString += b[i]
			i+=1
		#print("bytestring found :",byteString, " and the ascii for it is: ",bin_to_a.get(byteString,"(none)"))
		Ascii += bin_to_a.get(byteString,"(No)")
		byteString = ''
	print("Ascii is :", Ascii)
	return Ascii
	
def Ascii_to_hex(word):
	AtoHex = {	' ':'20',
				'!':'21',
				'"':'22',
				'#':'23',
				'$':'24',
				'%':'25',
				'&':'26',
				'\'':'27',
				'(':'28',
				')':'29',
				'*':'2A',
				'+':'2B',
				':':'2C',
				'-':'2D',
				'.':'2E',
				'/':'2F',
			    '0':'30',
			    '1':'31',
			    '2':'32',
			    '3':'33',
			    '4':'34',
			    '5':'35',
			    '6':'36',
			    '7':'37',
			    '8':'38',
			    '9':'39',
			    ':':'3A',
			    ';':'3B',
			    '<':'3C',
			    '=':'3D',
			    '>':'3E',
			    '?':'3F',
				'@':'40',
				'A':'41',
			    'B':'42',
			    'C':'43',
			    'D':'44',
			    'E':'45',
			    'F':'46',
			    'G':'47',
			    'H':'48',
			    'I':'49',
			    'J':'4A',
			    'K':'4B',
			    'L':'4C',
			    'M':'4D',
			    'N':'4E',
			    'O':'4F',
			    'P':'50',
			    'Q':'51',
			    'R':'52',
			    'S':'53',
			    'T':'54',
			    'U':'55',
			    'V':'56',
			    'W':'57',
			    'X':'58',
			    'Y':'59',
			    'Z':'5A',
			    '[':'5B',
			    '\\':'5C',
			    ']':'5D',
			    '↑':'5E',
			    '←':'5F',
				'@':'60',
			    'a':'61',
			    'b':'62',
			    'c':'63',
			    'd':'64',
			    'e':'65',
			    'f':'66',
			    'g':'67',
			    'h':'68',
			    'i':'69',
			    'j':'6A',
			    'k':'6B',
			    'l':'6C',
			    'm':'6D',
			    'n':'6E',
			    'o':'6F',
			    'p':'70',
			    'q':'71',
			    'r':'72',
			    's':'73',
			    't':'74',
			    'u':'75',
			    'v':'76',
			    'w':'77',
			    'x':'78',
			    'y':'79',
			    'z':'7A',
				'{':'7B',
			    '|':'7C',
			    '}':'7D',
			    '~':'7E'}    
	hexstring = ''
	
	for i in range(0, len(word)):	
		#print("number:", i," letter:",word[i],"\noutput is :",AtoHex[word[i]])
		hexstring += AtoHex[word[i]]
	
	print("The full hexstring is :",hexstring)
	return hexstring
	
def binary_xor (oneNum, twoNum):
	binaryXored = ''
	if(len(oneNum) != len(twoNum)):
		len1Num = len(oneNum)
		len2Num = len(twoNum)
		
		addhexPadZero = ''
		
		if(len1Num > len2Num):
			NoZero = len1Num - len2Num
			
			for z in range (0, NoZero):
				addhexPadZero += '0'
			addhexPadZero +=twoNum
			twoNum = addhexPadZero
		else:
			NoZero = len2Num - len1Num
			for z in range (0, NoZero):
				addhexPadZero += '0'
			addhexPadZero +=oneNum
			oneNum = addhexPadZero
			
	print("\nBinary Cipher text message 1:", oneNum)
	print("\nBinary Cipher text message 2:", twoNum)		
			
	#oneNum = hex_to_binary(oneNum)
	#twoNum = hex_to_binary(twoNum)
			
	#print("\nBinary Cipher text message 1:", oneNum)
	#print("\nBinary Cipher text message 2:", twoNum)
			
	for b in range (0, len(oneNum)):
		if(oneNum[b] == twoNum[b]):
			binaryXored += '0'
		else:
			binaryXored += '1'
			
	return binaryXored

option = {"-hex_to_binary": hex_to_binary,
		"-ascii_to_hex": Ascii_to_hex,
		"-binary_to_hex": binary_to_hex,
		"-binary_to_ascii": binary_to_Ascii,
		"-binary_xor": binary_xor
		}	
	
	
def xor_two_CipherMsg(c1,c2):
	print("Cipher text message 1:", c1,"\nCipher text message 2:", c2,"\n Converting hex to binary...")
	bC1 = cipherText_to_binary(c1)
	bC2 = cipherText_to_binary(c2)
	
	print("Binary Cipher text message 1:", bC1)
	print("\nBinary Cipher text message 2:", bC2)
	xored_bits = binary_xor(c1,c2)
	print("\nThe binary XOR of these mess:", xored_bits)

	print("\nBinary xor to ascii :", binary_to_Ascii(xored_bits))	
	

if (len(sys.argv) <= 2):
	print("Please enter one of the following arguments:\n -hex_to_binary\n -binary_to_hex\n -ascii_to_hex\n -binary_to_ascii\n -binary_xor")
else:
	print("testing")
	msg1 = sys.argv[1]
	msg2 = sys.argv[2]
	print("testing2")
	
	print("you have chosen option ", sys.argv[1])
	var = sys.argv[1]
	if(var == "-binary_xor"):
		print("The binary xor : ",binary_xor (sys.argv[2], sys.argv[3]))
	else:
		option[var](sys.argv[2])
	print("this is the end of the choise")


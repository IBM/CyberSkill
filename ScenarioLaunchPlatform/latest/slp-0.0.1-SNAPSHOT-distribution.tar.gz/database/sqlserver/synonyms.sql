/* ======================================================
   SYNONYMS
====================================================== */
-- Shortcut to tbl_crm_accounts
CREATE SYNONYM dbo.Accounts FOR dbo.tbl_crm_accounts;

-- Shortcut to view
CREATE SYNONYM dbo.MarketingCampaigns FOR dbo.vwMarketingCampaignDetail;
GO

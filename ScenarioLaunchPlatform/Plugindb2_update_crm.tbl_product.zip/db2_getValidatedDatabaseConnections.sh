#!/usr/bin/env bash
# db2_getValidatedDatabaseConnections.sh — POST a SQL query to the datasource API
# Example: ./db2_getValidatedDatabaseConnections

set -euo pipefail

LOG_DIR="/var/log/slp_logs"
TIMESTAMP="$(date '+%Y-%m-%d %H:%M:%S')"
FULL_LOG="${LOG_DIR}/slp_db2_run_query.log"
HEADERS_FILE="${LOG_DIR}/slp_db2_getValidatedDatabaseConnections_headers.log"
BODY_FILE="${LOG_DIR}/slp_db2_getValidatedDatabaseConnections_body.log"
TMP_BODY="$(mktemp)"



PAYLOAD=$(cat <<EOF
{
  "jwt": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6MSwiZmlyc3RuYW1lIjoiamFzb24iLCJzdXJuYW1lIjoiZmxvb2QiLCJlbWFpbCI6Imphc29uLmZsb29kQGVtYWlsLmNvbSIsInVzZXJuYW1lIjoibXl1c2VybmFtZSIsImFjdGl2ZSI6IjEiLCJhdXRobGV2ZWwiOjEsImlhdCI6MTczMzkxMzU1NywiZXhwIjoxNzMzOTEzNjE3fQ.mvDvSanNTCvN5puizSme7URjPbhWOkRfW3ZioUWz174"
}
EOF
)

echo "Payload db2_getValidatedDatabaseConnections.sh: $PAYLOAD"

###############################################################################
# 4. Call curl and log everything
###############################################################################

# Append timestamp to both logs
echo "=== $TIMESTAMP ===" | tee -a "$HEADERS_FILE" "$BODY_FILE" "$FULL_LOG"

# Run curl ONCE, capturing headers and body

  curl --silent --show-error --location --request POST \
       'http://127.0.0.1:80/api/getValidatedDatabaseConnections' \
       --header 'Content-Type: application/json' \
       --data-raw "${PAYLOAD}" \
 	-dump-header - \
        --output "$TMP_BODY" | tee -a "$HEADERS_FILE" >> "$FULL_LOG"

# Append body to body log and full log
cat "$TMP_BODY" | tee -a "$BODY_FILE" >> "$FULL_LOG"

# Clean up
rm -f "$TMP_BODY"
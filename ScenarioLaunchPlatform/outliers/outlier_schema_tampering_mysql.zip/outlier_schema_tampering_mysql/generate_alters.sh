#!/bin/bash
# ============================================================================
# Script: generate_alters.sh
# Purpose: Generate SQL file with 1000 individual ALTER commands
# Output: execute_1000_alters.sql
# ============================================================================

OUTPUT_FILE="execute_1000_alters.sql"

echo "Generating 1000 individual ALTER commands..."

# Start the SQL file
cat > "$OUTPUT_FILE" << 'EOF'
-- ============================================================================
-- Script: execute_1000_alters.sql
-- Purpose: Execute 1000 individual ALTER commands on testdb database
-- Database: testdb
-- Generated with individual ALTER statements (no procedures)
-- ============================================================================

-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS testdb;
USE testdb;

-- ============================================================================
-- CREATE 100 BASE TABLES (to be altered)
-- ============================================================================

EOF

# Generate 100 base tables (each will be altered 10 times = 1000 alters)
for i in $(seq 1 100); do
    echo "CREATE TABLE IF NOT EXISTS ALTER_TEST_TABLE_${i} (" >> "$OUTPUT_FILE"
    echo "    id INT AUTO_INCREMENT PRIMARY KEY," >> "$OUTPUT_FILE"
    echo "    data VARCHAR(100)," >> "$OUTPUT_FILE"
    echo "    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" >> "$OUTPUT_FILE"
    echo ");" >> "$OUTPUT_FILE"
    echo "" >> "$OUTPUT_FILE"
done

# Add separator
cat >> "$OUTPUT_FILE" << 'EOF'
-- ============================================================================
-- ALTER COMMANDS (1000 individual ALTER TABLE statements)
-- ============================================================================
-- Pattern: 10 different ALTER operations on each of 100 tables = 1000 total
-- Operations: ADD COLUMN, MODIFY COLUMN, DROP COLUMN, ADD INDEX, DROP INDEX,
--             RENAME COLUMN, CHANGE COLUMN, ALTER COLUMN, ADD CONSTRAINT, etc.
-- ============================================================================

EOF

# Generate 1000 ALTER statements (10 operations per table, 100 tables)
for i in $(seq 1 100); do
    table_name="ALTER_TEST_TABLE_${i}"
    
    # ALTER 1: Add a new column
    echo "ALTER TABLE ${table_name} ADD COLUMN col_new_${i}_1 VARCHAR(50);" >> "$OUTPUT_FILE"
    
    # ALTER 2: Modify existing column
    echo "ALTER TABLE ${table_name} MODIFY COLUMN data VARCHAR(200);" >> "$OUTPUT_FILE"
    
    # ALTER 3: Add another column
    echo "ALTER TABLE ${table_name} ADD COLUMN col_new_${i}_2 INT DEFAULT 0;" >> "$OUTPUT_FILE"
    
    # ALTER 4: Add index
    echo "ALTER TABLE ${table_name} ADD INDEX idx_data_${i} (data);" >> "$OUTPUT_FILE"
    
    # ALTER 5: Add another column
    echo "ALTER TABLE ${table_name} ADD COLUMN col_new_${i}_3 DECIMAL(10,2);" >> "$OUTPUT_FILE"
    
    # ALTER 6: Rename column
    echo "ALTER TABLE ${table_name} RENAME COLUMN col_new_${i}_1 TO col_renamed_${i}_1;" >> "$OUTPUT_FILE"
    
    # ALTER 7: Add another column
    echo "ALTER TABLE ${table_name} ADD COLUMN col_new_${i}_4 TEXT;" >> "$OUTPUT_FILE"
    
    # ALTER 8: Drop a column
    echo "ALTER TABLE ${table_name} DROP COLUMN col_new_${i}_2;" >> "$OUTPUT_FILE"
    
    # ALTER 9: Add unique index
    echo "ALTER TABLE ${table_name} ADD UNIQUE INDEX idx_unique_${i} (col_renamed_${i}_1);" >> "$OUTPUT_FILE"
    
    # ALTER 10: Modify column with NOT NULL
    echo "ALTER TABLE ${table_name} MODIFY COLUMN col_new_${i}_3 DECIMAL(10,2) NOT NULL DEFAULT 0.00;" >> "$OUTPUT_FILE"
    
    echo "" >> "$OUTPUT_FILE"
done

# Add verification section
cat >> "$OUTPUT_FILE" << 'EOF'
-- ============================================================================
-- VERIFICATION
-- ============================================================================

-- Check table structures
SELECT 
    table_name,
    COUNT(*) as column_count
FROM information_schema.columns 
WHERE table_schema = 'testdb' 
AND table_name LIKE 'ALTER_TEST_TABLE_%'
GROUP BY table_name
ORDER BY table_name
LIMIT 10;

-- Check indexes created
SELECT 
    table_name,
    COUNT(*) as index_count
FROM information_schema.statistics 
WHERE table_schema = 'testdb' 
AND table_name LIKE 'ALTER_TEST_TABLE_%'
GROUP BY table_name
ORDER BY table_name
LIMIT 10;

-- Summary
SELECT 
    COUNT(DISTINCT table_name) as tables_altered,
    COUNT(*) as total_columns
FROM information_schema.columns 
WHERE table_schema = 'testdb' 
AND table_name LIKE 'ALTER_TEST_TABLE_%';

SELECT 'All 1000 ALTER commands executed successfully!' AS Result;

-- Made with Bob
EOF

echo "✓ Generated $OUTPUT_FILE with 1000 individual ALTER commands"
echo "✓ File size: $(wc -l < "$OUTPUT_FILE") lines"
echo "✓ Pattern: 100 tables × 10 ALTER operations each = 1000 total"
echo "✓ Operations include: ADD COLUMN, MODIFY, DROP, ADD INDEX, RENAME, etc."
echo ""
echo "To execute:"
echo "  mysql -h<host> -P<port> -uroot -p<password> < $OUTPUT_FILE"

# Made with Bob

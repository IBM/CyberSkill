# MySQL Timed SELECT Commands Outlier Test

## Overview
This folder contains scripts to execute SELECT commands with a **time-based anomaly pattern** for MySQL outlier detection testing. The script simulates normal behavior followed by a sudden spike in SELECT operations, which could indicate data exfiltration or data leak attempts.

## Purpose
- Test detection of time-based SELECT operation anomalies
- Simulate normal baseline: 50 selects/hour for 4 hours
- Create anomaly spike: 1000 selects in the 5th hour
- Generate realistic outlier patterns for security monitoring
- Test anomaly detection systems with temporal patterns
- Detect potential data leak or exfiltration attempts
- **Automatically creates unique user and database for each run**

## Files

### 1. run_timed_selects_background.sh
Main script that executes SELECT operations with time-based pattern.

**What it does:**
- **Automatically creates a unique user and database for each run**
- Creates a table with 10,000 test records
- Executes 50 SELECT commands per hour for 4 hours (baseline)
- Uses varied SELECT queries (simple, WHERE, COUNT, JOIN, aggregation)
- Waits 1 hour between each batch
- Executes 1000 SELECT commands in hour 5 (SPIKE)
- Logs all operations with timestamps
- Can run in foreground or background mode

**Pattern:**
- Hours 1-4: 50 selects each = 200 total (baseline)
- Hour 5: 1000 selects = SPIKE (anomaly)
- Total: 1200 SELECT operations over 5 hours


## Prerequisites
- MySQL Server 5.7 or higher
- MySQL client installed
- **Root access** (required for auto-creating database and user)
- Sufficient server resources to handle 205K+ queries
- Time: ~5 hours for full execution

## Usage

### Step 1 : Background Execution (Recommended for 5-hour run)
```bash
./run_timed_selects_background.sh <host> <port> <root_password> background
```

**Example:**
```bash
./run_timed_selects_background.sh localhost 3306 MyRootPassword123 bg
```

### Monitor Background Execution
```bash
# View real-time logs
tail -f logs/timed_selects_background_*.log

# Check if still running
ps aux | grep run_timed_selects_background.sh

# Stop background execution
pkill -f run_timed_selects_background.sh
```

## What Gets Created and Queried

### Table Structure
- **Table Name:** `select_test_data`
- **Columns:**
  - `id` (INT, AUTO_INCREMENT, PRIMARY KEY)
  - `record_number` (INT, NOT NULL)
  - `data` (VARCHAR(255))
  - `category` (VARCHAR(50))
  - `created_at` (TIMESTAMP)
- **Indexes:**
  - `idx_record_number` on `record_number`
  - `idx_category` on `category`

### Test Data (10,000 records)
The script automatically inserts 10,000 records at the start:
```sql
INSERT INTO select_test_data (record_number, data, category) VALUES
(1, 'Test data for record 1', 'category_1'),
(2, 'Test data for record 2', 'category_2'),
...
(10000, 'Test data for record 10000', 'category_10');
```

### SELECT Query Types

The script uses 5 different types of SELECT queries for realism:

1. **Simple SELECT by ID** (20% of queries)
   ```sql
   SELECT * FROM select_test_data WHERE record_number = N LIMIT 1;
   ```

2. **SELECT with WHERE clause** (20% of queries)
   ```sql
   SELECT * FROM select_test_data WHERE category = 'category_X' LIMIT 10;
   ```

3. **SELECT with COUNT** (20% of queries)
   ```sql
   SELECT COUNT(*) FROM select_test_data WHERE record_number > N;
   ```

4. **SELECT with JOIN** (20% of queries)
   ```sql
   SELECT t1.record_number, t2.data 
   FROM select_test_data t1 
   JOIN select_test_data t2 ON t1.category = t2.category 
   WHERE t1.record_number = N LIMIT 5;
   ```

5. **SELECT with aggregation** (20% of queries)
   ```sql
   SELECT category, COUNT(*) as count, MAX(record_number) as max_record 
   FROM select_test_data 
   GROUP BY category;
   ```

### SELECT Operations Pattern

**Hours 1-10 (Normal Baseline):**
- 50 SELECT operations per hour
- Mixed query types for realistic patterns
- Simulates normal data access

**Hour 11 (SPIKE - Anomaly):**
- 1000 SELECT operations in one hour
- Massive data query spike
- Could indicate data exfiltration attempt

### Total Operations
- 200 normal SELECT commands (hours 1-4)
- 1000 spike SELECT commands (hour 5)
- **Total: 1200 SELECT operations**

## Database and User
- **Database Name:** `select_db_YYYYMMDD_HHMMSS` (automatically generated)
- **User Name:** `select_user_YYYYMMDD_HHMMSS` (automatically generated)
- **Created automatically** with unique timestamp-based names
- User has full privileges on the database
- All operations occur in the unique database

## Execution Timeline

```
Hour 1:  50 selects  → Sleep 1 hour
Hour 2:  50 selects  → Sleep 1 hour
Hour 3:  50 selects  → Sleep 1 hour
Hour 4:  50 selects  → Sleep 1 hour
Hour 5:  1000 selects (SPIKE!) → Complete
```

**Total Duration:** ~5 hours

## Logs

The script creates detailed logs in the `logs/` directory:

### Log Files
- `timed_selects_YYYYMMDD_HHMMSS.log` - Main execution log
- `timed_selects_background_YYYYMMDD_HHMMSS.log` - Background mode log
- `selects_hour_N_YYYYMMDD_HHMMSS.log` - Individual hour logs (1-5)
- `timed_selects_pid_YYYYMMDD_HHMMSS.txt` - Process ID file

### Log Contents
Each log includes:
- Timestamp for each operation
- Connection status
- Number of selects executed per hour
- Query results (in individual hour logs)
- Success/failure status
- Total duration and summary

## Verification

After execution, check the results (replace `select_db_YYYYMMDD_HHMMSS` with your actual database name from the logs):

```sql
USE select_db_20231230_120000;  -- Replace with your actual database name

-- Check the test data table
SELECT COUNT(*) AS TotalRecords FROM select_test_data;

-- Expected: 10,000 records

-- Check data distribution by category
SELECT category, COUNT(*) as count
FROM select_test_data
GROUP BY category
ORDER BY category;

-- Sample some records
SELECT * FROM select_test_data LIMIT 10;

-- Check table structure
DESCRIBE select_test_data;
```

## Prerequisites

- MySQL Server 5.7 or higher
- MySQL client installed
- Root user access for creating databases and users
- Sufficient disk space for test data
- Time: ~5 hours for full execution

## Cleanup

To remove the test database and user (replace with your actual names from the logs):

```sql
-- Drop the database (this removes all tables)
DROP DATABASE IF EXISTS select_db_20231230_120000;

-- Drop the user
DROP USER IF EXISTS 'select_user_20231230_120000'@'%';

-- Flush privileges
FLUSH PRIVILEGES;
```

Or use a cleanup script:

```bash
#!/bin/bash
# Replace with your actual database and user names
DB_NAME="select_db_20231230_120000"
DB_USER="select_user_20231230_120000"

mysql -h<host> -P<port> -uroot -p<password> <<EOF
DROP DATABASE IF EXISTS \`$DB_NAME\`;
DROP USER IF EXISTS '$DB_USER'@'%';
FLUSH PRIVILEGES;
EOF
```

**Note:** The database name and user name are shown in the script output and logs when you run the script.

## Troubleshooting

### Issue: Permission Denied
```bash
chmod +x run_timed_selects_background.sh
```

### Issue: MySQL Connection Failed
Check:
- Host and port are correct
- Password is correct
- MySQL server is running
- User has SELECT privileges

### Issue: Background Process Not Starting
```bash
# Check if nohup is available
which nohup

# Check logs directory permissions
ls -la logs/

# Verify script syntax
bash -n run_timed_selects_background.sh
```

### Issue: Script Stops Unexpectedly
```bash
# Check the logs
tail -100 logs/timed_selects_*.log

# Check for MySQL errors
tail -100 logs/selects_hour_*_*.log

# Verify MySQL is still running
mysql -h<host> -P<port> -u<user> -p<password> -e "SELECT 1;"
```

### Issue: Cannot Find Process
```bash
# Check PID file
cat logs/timed_selects_pid_*.txt

# Check if process is running
ps -p <PID>

# Find all related processes
ps aux | grep -i select
```

### Issue: Slow Query Performance
```sql
-- Check if indexes exist
SHOW INDEX FROM select_test_data;

-- Analyze table
ANALYZE TABLE select_test_data;

-- Check query execution plan
EXPLAIN SELECT * FROM select_test_data WHERE record_number = 100;
```

## Security Notes

⚠️ **WARNING:** This script simulates data exfiltration patterns!

- Only run in test environments
- Never run on production databases
- Simulates potential data leak scenarios
- Monitor for security alerts during execution
- Test in isolated environment first
- Useful for testing DLP (Data Loss Prevention) systems

## Example Output

### Foreground Mode
```
============================================================================
Timed SELECT Operations - Background Execution
============================================================================
Configuration:
  Host: localhost
  Port: 3306
  Pattern: 50 selects/hour for 10 hours, then 1000 selects in hour 11
  Sleep Between Batches: 1 hour(s)
  Log Directory: /path/to/logs
  Main Log: /path/to/logs/timed_selects_20231230_120000.log
============================================================================

Testing MySQL connection...
✓ MySQL connection successful

========================================================================
Hour 1 of 11
========================================================================
Hour 1: Executing 50 SELECT commands...
  ✓ Hour 1: 50 selects completed successfully

Sleeping for 1 hour(s) before next batch...
Next batch (Hour 2) will start at: 2023-12-30 13:00:00

...

========================================================================
Hour 11 of 11 - SPIKE: 1000 SELECT COMMANDS
========================================================================
Hour 11: Executing 1000 SELECT commands...
  ✓ Hour 11: 1000 selects completed successfully

============================================================================
Timed SELECT Operations Complete!
============================================================================
Total Batches: 11
Total SELECTs: 1500 (500 normal + 1000 spike)
Total Duration: 11h 15m 30s
Logs Directory: /path/to/logs
Main Log: /path/to/logs/timed_selects_20231230_120000.log
============================================================================
```

### Background Mode
```
============================================================================
Starting Timed SELECT Operations in Background
============================================================================
Host: localhost
Port: 3306
Background Log: /path/to/logs/timed_selects_background_20231230_120000.log
============================================================================

The script is now running in the background.
To monitor progress:
  tail -f /path/to/logs/timed_selects_background_20231230_120000.log

To check if it's still running:
  ps aux | grep run_timed_selects_background.sh

To stop it:
  pkill -f run_timed_selects_background.sh
============================================================================
Background Process ID: 12345
PID saved to: /path/to/logs/timed_selects_pid_20231230_120000.txt

Script launched successfully!
```

## Integration with Monitoring

This script is designed to trigger alerts in:
- Database activity monitors
- Security information and event management (SIEM) systems
- Audit log analyzers
- Anomaly detection systems
- Data Loss Prevention (DLP) systems
- User Behavior Analytics (UBA) systems

Look for:
- Sudden spike in SELECT commands (hour 11)
- Deviation from baseline pattern (50 selects/hour)
- Temporal anomaly detection
- Potential data exfiltration patterns
- Unusual data access activity
- High-volume query patterns

## Time-Based Anomaly Pattern

| Hour | SELECT Count | Query Types | Type | Purpose |
|------|--------------|-------------|------|---------|
| 1 | 50 | Mixed | Baseline | Normal activity |
| 2 | 50 | Mixed | Baseline | Normal activity |
| 3 | 50 | Mixed | Baseline | Normal activity |
| 4 | 50 | Mixed | Baseline | Normal activity |
| 5 | 50 | Mixed | Baseline | Normal activity |
| 6 | 50 | Mixed | Baseline | Normal activity |
| 7 | 50 | Mixed | Baseline | Normal activity |
| 8 | 50 | Mixed | Baseline | Normal activity |
| 9 | 50 | Mixed | Baseline | Normal activity |
| 10 | 50 | Mixed | Baseline | Normal activity |
| **11** | **1000** | **Mixed** | **SPIKE** | **Anomaly/Data Leak** |
| **Total** | **1500** | - | - | **Complete** |

## Use Cases

1. **Data Exfiltration Detection**
   - Test detection of mass data queries
   - Simulate insider threat scenarios
   - Validate DLP systems

2. **Anomaly Detection Testing**
   - Verify baseline establishment
   - Test spike detection algorithms
   - Validate alert thresholds

3. **Security Monitoring**
   - Test SIEM integration
   - Validate audit logging
   - Check query monitoring systems

4. **Performance Testing**
   - Measure SELECT query performance
   - Test database load handling
   - Evaluate index effectiveness

## Made with Bob
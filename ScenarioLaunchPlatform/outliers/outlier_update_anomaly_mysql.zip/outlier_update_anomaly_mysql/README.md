# MySQL UPDATE Command Anomaly Detection Test

## Overview
This script simulates an UPDATE command anomaly pattern to test database security monitoring systems. It establishes a baseline of normal UPDATE activity, then creates a spike that should trigger anomaly detection.

## Pattern
- **Hours 1-4**: 50 UPDATE commands per hour (baseline behavior)
- **Hour 5**: 1001 UPDATE commands (anomaly spike - 20x increase)
- **Total**: 1201 UPDATE commands over 5 hours

## Features
- ✅ Creates unique database and user for each run (timestamped)
- ✅ Automatic cleanup isolation (each run is independent)
- ✅ Varied UPDATE queries for realistic patterns
- ✅ Progress tracking and detailed logging
- ✅ Foreground or background execution modes
- ✅ Proper error handling with exit code tracking

## Prerequisites
- MySQL Server 5.7 or higher
- MySQL client installed
- **Root access** (required for auto-creating database and user)
- Sufficient server resources to handle 205K+ queries
- Time: ~5 hours for full execution
- **Enable Demo Mode** - Ensure demo mode is enabled in your GDP system before running the test

## Usage


### Background Mode 
```bash
./run_timed_updates_background.sh <host> <port> <root_password> background
```

Example:
```bash
./run_timed_updates_background.sh localhost 3306 MyRootPass123 bg
```

## What It Does

### 1. Setup Phase
- Creates unique database: `update_db_<timestamp>`
- Creates unique user: `update_user_<timestamp>`
- Grants all privileges to the user on the database
- Creates test table with 10,000 records

### 2. Execution Phase

**Hours 1-4 (Baseline):**
- Executes 50 UPDATE commands per hour
- Varies UPDATE types:
  - Simple counter increments
  - Status field updates
  - Data field modifications
  - Multi-field updates
  - Conditional updates with LIMIT

**Hour 5 (Anomaly Spike):**
- Executes 1001 UPDATE commands
- Same variety of UPDATE types
- Should trigger anomaly detection

### 3. UPDATE Query Types
The script uses 5 different UPDATE patterns:
1. **Counter increment**: `UPDATE ... SET counter = counter + 1`
2. **Status update**: `UPDATE ... SET status = 'processing'`
3. **Data modification**: `UPDATE ... SET data = CONCAT('Updated at ', NOW())`
4. **Multi-field update**: `UPDATE ... SET counter = counter + 1, status = 'processing'`
5. **Conditional update**: `UPDATE ... WHERE record_number % 10 = X LIMIT 10`

## Monitoring

### Check if running (background mode)
```bash
ps aux | grep run_timed_updates_background.sh
```

### Monitor progress
```bash
tail -f logs/timed_updates_background_<timestamp>.log
```

### Stop execution
```bash
pkill -f run_timed_updates_background.sh
```

## Logs
All logs are stored in the `logs/` directory:
- `timed_updates_<timestamp>.log` - Main execution log
- `timed_updates_background_<timestamp>.log` - Background execution log
- `updates_hour_<N>_<timestamp>.log` - Individual hour logs
- `timed_updates_pid_<timestamp>.txt` - Process ID file

## Expected Detection
Security monitoring systems should detect:
- **UPDATE Command Anomaly**: 1001 updates in hour 5 vs 50 in previous hours
- **Volume Spike**: 20x increase in UPDATE activity
- **Behavioral Change**: Sudden surge in data modification operations

## Database Objects Created
- Database: `update_db_<timestamp>`
- User: `update_user_<timestamp>`
- Table: `update_test_data` (10,000 records)
  - Columns: id, record_number, data, status, counter, last_updated
  - Indexes on: record_number, status

## Cleanup
Each run creates isolated resources with unique timestamps. To clean up:

```bash
# List all test databases
mysql -uroot -p -e "SHOW DATABASES LIKE 'update_db_%';"

# Drop specific database
mysql -uroot -p -e "DROP DATABASE update_db_<timestamp>;"

# Drop specific user
mysql -uroot -p -e "DROP USER 'update_user_<timestamp>'@'%';"
```

## Troubleshooting

### Connection Issues
- Verify MySQL is running: `systemctl status mysql`
- Check host and port: `mysql -h<host> -P<port> -uroot -p`
- Verify root password

### Permission Issues
- Ensure root user has CREATE DATABASE and CREATE USER privileges
- Check firewall rules if connecting remotely

### Script Issues
- Check logs in `logs/` directory
- Verify script is executable: `chmod +x run_timed_updates_background.sh`
- Ensure bash is available: `which bash`

## Notes
- Each execution creates a NEW database and user (no conflicts)
- Sleep duration between hours: 1 hour (configurable in script)
- Total execution time: ~5 hours
- All UPDATE operations are logged for audit trail

## Security Considerations
- User passwords are randomly generated with timestamp
- Each test is isolated in its own database
- No impact on existing databases or users
- All operations are auditable through MySQL logs

---
**Made with Bob**
## Enable Demo Mode and Enable ATA in GDP

To enable demo mode and ATA (Advanced Threat Analytics) in GDP (Guardium Data Protection):

### Enable Demo Mode

1. **Access GDP Console**
   - Log in to your Guardium Data Protection console
   - Navigate to **Setup** > **Tools and Views** > **System Settings**

2. **Enable Demo Mode**
   - Go to **Demo Mode Settings**
   - Check the box for **Enable Demo Mode**
   - Click **Save**

### Enable ATA (Advanced Threat Analytics)

1. **Access ATA Settings**
   - Navigate to **Setup** > **Tools and Views** > **Advanced Threat Analytics**

2. **Enable ATA**
   - Check **Enable Advanced Threat Analytics**
   - Configure the following settings:
     - **Baseline Period**: Set appropriate baseline period (recommended: 7-14 days)
     - **Sensitivity Level**: Choose sensitivity level (Low/Medium/High)
     - **Alert Threshold**: Configure alert thresholds based on your requirements

3. **Configure ATA Policies**
   - Go to **Policy** > **ATA Policies**
   - Enable relevant policies for outlier detection:
     - Account Takeover Detection
     - Denial of Service Detection
     - Data Leak Detection
     - Schema Tampering Detection
     - Privilege Abuse Detection
     - Failed Login Detection

4. **Save Configuration**
   - Click **Save** to apply changes
   - ATA will start monitoring and learning baseline behavior

### Verification

After enabling demo mode and ATA:
- Run the outlier test scripts
- Monitor the GDP console for ATA alerts
- Check **Reports** > **ATA Reports** for detected anomalies
- Verify alerts are generated for the simulated attack patterns

### Notes

- Demo mode is useful for testing and demonstration purposes
- ATA requires a baseline period to establish normal behavior patterns
- Adjust sensitivity and thresholds based on your environment
- Review and tune ATA policies regularly for optimal detection



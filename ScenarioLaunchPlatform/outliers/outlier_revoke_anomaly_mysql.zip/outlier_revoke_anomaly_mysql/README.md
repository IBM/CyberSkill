# MySQL REVOKE Command Anomaly Detection Test

## Overview
This script simulates a REVOKE command anomaly pattern to test database security monitoring systems. It establishes a baseline of normal privilege revocation activity, then creates a spike that should trigger anomaly detection for potential privilege escalation attacks or insider threats.

## Pattern
- **Hours 1-4**: 50 REVOKE commands per hour (baseline behavior)
- **Hour 5**: 1001 REVOKE commands (anomaly spike - 20x increase)
- **Total**: 1201 REVOKE commands over 5 hours

## Features
- ✅ Creates unique database and admin user for each run (timestamped)
- ✅ Creates 2000 test users with various privileges
- ✅ Automatic cleanup isolation (each run is independent)
- ✅ Varied REVOKE operations (SELECT, INSERT, UPDATE, DELETE)
- ✅ Progress tracking and detailed logging
- ✅ Foreground or background execution modes
- ✅ Proper error handling with exit code tracking
- ✅ Auto re-grant privileges to enable continuous revocation

## Prerequisites
- MySQL Server 5.7 or higher
- MySQL client installed
- **Root access** (required for auto-creating database and user)
- Sufficient server resources to handle 205K+ queries
- Time: ~5 hours for full execution
- **Enable Demo Mode** - Ensure demo mode is enabled in your GDP system before running the test

## Usage


### Background Mode 
```bash
./run_timed_revokes_background.sh <host> <port> <root_password> background
```

Example:
```bash
./run_timed_revokes_background.sh localhost 3306 MyRootPass123 bg
```

## What It Does

### 1. Setup Phase
- Creates unique database: `revoke_db_<timestamp>`
- Creates unique admin user: `revoke_admin_<timestamp>` with GRANT OPTION
- Creates 2000 test users: `revoke_test_user_<timestamp>_1` through `revoke_test_user_<timestamp>_2000`
- Grants each test user: SELECT, INSERT, UPDATE, DELETE privileges

### 2. Execution Phase

**Hours 1-4 (Baseline):**
- Executes 50 REVOKE commands per hour
- Cycles through test users (reuses users with re-granted privileges)
- Varies REVOKE types:
  - REVOKE SELECT
  - REVOKE INSERT
  - REVOKE UPDATE
  - REVOKE DELETE

**Hour 5 (Anomaly Spike):**
- Executes 1001 REVOKE commands
- Same variety of REVOKE types
- Should trigger anomaly detection

### 3. REVOKE Operation Types
The script uses 4 different REVOKE patterns:
1. **REVOKE SELECT**: `REVOKE SELECT ON database.* FROM 'user'@'%'`
2. **REVOKE INSERT**: `REVOKE INSERT ON database.* FROM 'user'@'%'`
3. **REVOKE UPDATE**: `REVOKE UPDATE ON database.* FROM 'user'@'%'`
4. **REVOKE DELETE**: `REVOKE DELETE ON database.* FROM 'user'@'%'`

After each REVOKE, the privilege is re-granted to enable continuous testing.

## Monitoring

### Check if running (background mode)
```bash
ps aux | grep run_timed_revokes_background.sh
```

### Monitor progress
```bash
tail -f logs/timed_revokes_background_<timestamp>.log
```

### Stop execution
```bash
pkill -f run_timed_revokes_background.sh
```

## Logs
All logs are stored in the `logs/` directory:
- `timed_revokes_<timestamp>.log` - Main execution log
- `timed_revokes_background_<timestamp>.log` - Background execution log
- `revokes_hour_<N>_<timestamp>.log` - Individual hour logs
- `create_users_<timestamp>.log` - User creation log
- `timed_revokes_pid_<timestamp>.txt` - Process ID file

## Expected Detection
Security monitoring systems should detect:
- **REVOKE Command Anomaly**: 1001 revokes in hour 5 vs 50 in previous hours
- **Volume Spike**: 20x increase in privilege revocation activity
- **Behavioral Change**: Sudden surge in permission removal operations
- **Potential Threats**:
  - Insider threat removing access
  - Privilege escalation attack cleanup
  - Unauthorized access control changes

## Database Objects Created
- Database: `revoke_db_<timestamp>`
- Admin User: `revoke_admin_<timestamp>` (with GRANT OPTION)
- Test Users: `revoke_test_user_<timestamp>_1` through `revoke_test_user_<timestamp>_2000`
- Table: `revoke_test_table` (simple test table)

## Cleanup
Each run creates isolated resources with unique timestamps. To clean up:

```bash
# List all test databases
mysql -uroot -p -e "SHOW DATABASES LIKE 'revoke_db_%';"

# Drop specific database
mysql -uroot -p -e "DROP DATABASE revoke_db_<timestamp>;"

# Drop admin user
mysql -uroot -p -e "DROP USER 'revoke_admin_<timestamp>'@'%';"

# Drop all test users (be careful!)
mysql -uroot -p -e "SELECT CONCAT('DROP USER ''', user, '''@''%'';') FROM mysql.user WHERE user LIKE 'revoke_test_user_%';"
```

## Troubleshooting

### Connection Issues
- Verify MySQL is running: `systemctl status mysql`
- Check host and port: `mysql -h<host> -P<port> -uroot -p`
- Verify root password

### Permission Issues
- Ensure root user has CREATE DATABASE, CREATE USER, and GRANT privileges
- Check firewall rules if connecting remotely
- Verify max_user_connections setting

### Script Issues
- Check logs in `logs/` directory
- Verify script is executable: `chmod +x run_timed_revokes_background.sh`
- Ensure bash is available: `which bash`

### User Creation Limits
- MySQL has default limits on number of users
- Check `max_user_connections` and `max_connections` settings
- Script creates 2000 users - ensure your MySQL can handle this

## Notes
- Each execution creates NEW database, admin user, and test users (no conflicts)
- Sleep duration between hours: 1 hour (configurable in script)
- Total execution time: ~5 hours
- All REVOKE operations are logged for audit trail
- Privileges are automatically re-granted after each REVOKE to enable continuous testing

## Security Considerations
- Admin user passwords are randomly generated with timestamp
- Each test is isolated in its own database
- No impact on existing databases or users
- All operations are auditable through MySQL logs
- Test users have limited privileges (only on test database)

## Use Cases
This test simulates:
1. **Insider Threat**: Malicious admin removing user access
2. **Privilege Escalation Cleanup**: Attacker removing traces
3. **Mass Access Revocation**: Unauthorized bulk permission changes
4. **Security Policy Violation**: Abnormal privilege management activity

---
**Made with Bob**
## Enable Demo Mode and Enable ATA in GDP

To enable demo mode and ATA (Advanced Threat Analytics) in GDP (Guardium Data Protection):

### Enable Demo Mode

1. **Access GDP Console**
   - Log in to your Guardium Data Protection console
   - Navigate to **Setup** > **Tools and Views** > **System Settings**

2. **Enable Demo Mode**
   - Go to **Demo Mode Settings**
   - Check the box for **Enable Demo Mode**
   - Click **Save**

### Enable ATA (Advanced Threat Analytics)

1. **Access ATA Settings**
   - Navigate to **Setup** > **Tools and Views** > **Advanced Threat Analytics**

2. **Enable ATA**
   - Check **Enable Advanced Threat Analytics**
   - Configure the following settings:
     - **Baseline Period**: Set appropriate baseline period (recommended: 7-14 days)
     - **Sensitivity Level**: Choose sensitivity level (Low/Medium/High)
     - **Alert Threshold**: Configure alert thresholds based on your requirements

3. **Configure ATA Policies**
   - Go to **Policy** > **ATA Policies**
   - Enable relevant policies for outlier detection:
     - Account Takeover Detection
     - Denial of Service Detection
     - Data Leak Detection
     - Schema Tampering Detection
     - Privilege Abuse Detection
     - Failed Login Detection

4. **Save Configuration**
   - Click **Save** to apply changes
   - ATA will start monitoring and learning baseline behavior

### Verification

After enabling demo mode and ATA:
- Run the outlier test scripts
- Monitor the GDP console for ATA alerts
- Check **Reports** > **ATA Reports** for detected anomalies
- Verify alerts are generated for the simulated attack patterns

### Notes

- Demo mode is useful for testing and demonstration purposes
- ATA requires a baseline period to establish normal behavior patterns
- Adjust sensitivity and thresholds based on your environment
- Review and tune ATA policies regularly for optimal detection



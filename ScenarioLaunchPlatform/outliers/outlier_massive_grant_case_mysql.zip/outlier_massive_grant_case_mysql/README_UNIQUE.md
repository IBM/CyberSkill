# MySQL Massive Grant Outlier Test - WITH UNIQUE NAMES

## Overview
This version creates **unique database names, table names, and user names** for each test run, allowing multiple tests on the same system without conflicts. This ensures proper learning and baseline establishment for outlier detection.

## Why Unique Names?
- **Multiple Test Runs**: Run tests repeatedly on the same system
- **No Conflicts**: Each run uses different database/user names
- **Proper Learning**: Outlier detection systems can establish separate baselines
- **Parallel Testing**: Run multiple tests simultaneously (different configs)

## Naming Convention
Each test run generates unique names with timestamp suffix:
- Database: `outlier_grant_test_YYYYMMDD_HHMMSS`
- Grant Giver: `grant_giver_YYYYMMDD_HHMMSS`
- Grant Receiver: `grant_receiver_YYYYMMDD_HHMMSS`

Example:
- Database: `outlier_grant_test_20231223_143022`
- Users: `grant_giver_20231223_143022`, `grant_receiver_20231223_143022`

## Quick Start

### Step 1: Setup with Unique Names
```bash
cd outlier_massive_grant_case_mysql
./setup_with_unique_names.sh
```

Output will show:
```
[UNIQUE] Unique suffix for this run: 20231223_143022
[UNIQUE] Database name: outlier_grant_test_20231223_143022
[UNIQUE] Grant giver user: grant_giver_20231223_143022
[UNIQUE] Grant receiver user: grant_receiver_20231223_143022
...
Configuration saved to: config_20231223_143022.sh
```

### Step 2: Run Test in Background
Use the config file created in Step 1:
```bash
./start_test_unique.sh config_20231223_143022.sh
```

You can now exit the terminal - the test will continue running!

### Step 3: Check Status
```bash
# View all config files (one per test run)
ls -la config_*.sh

# Check specific test status
tail -f logs/grant_scenario_20231223_143022_*.log
```

### Step 4: Cleanup Specific Test
```bash
./cleanup_unique.sh config_20231223_143022.sh
```

## Running Multiple Tests

You can run multiple tests simultaneously or sequentially:

```bash
# Run 1
./setup_with_unique_names.sh
# Note the config file: config_20231223_140000.sh
./start_test_unique.sh config_20231223_140000.sh

# Run 2 (different names, no conflict!)
./setup_with_unique_names.sh
# Note the config file: config_20231223_150000.sh
./start_test_unique.sh config_20231223_150000.sh

# Run 3
./setup_with_unique_names.sh
# Note the config file: config_20231223_160000.sh
./start_test_unique.sh config_20231223_160000.sh
```

Each run will have:
- Unique database name
- Unique user names
- Separate log files
- Independent execution

## Configuration Files

Each test run creates a config file: `config_YYYYMMDD_HHMMSS.sh`

Example content:
```bash
# Configuration for test run: 20231223_143022
export DB_NAME="outlier_grant_test_20231223_143022"
export GRANT_GIVER="grant_giver_20231223_143022"
export GRANT_RECEIVER="grant_receiver_20231223_143022"
export UNIQUE_SUFFIX="20231223_143022"
export MYSQL_PASSWORD="Mysqlpswd@123"
```

## Monitoring Multiple Tests

### List All Active Tests
```bash
# Show all config files
ls -la config_*.sh

# Show all running processes
ps aux | grep run_unique
```

### View Logs for Specific Test
```bash
# Replace SUFFIX with your test's unique suffix
tail -f logs/grant_scenario_SUFFIX_*.log
```

### Check All Test Logs
```bash
# View all grant scenario logs
ls -la logs/grant_scenario_*

# View latest log entries from all tests
tail -20 logs/grant_scenario_*.log
```

## Test Pattern (Same for All Runs)
```
Run 1 (Hour 1): Grant SELECT on Object1  → 1 grant
    ↓ [1 hour sleep]
Run 2 (Hour 2): Grant SELECT on Object2  → 1 grant
    ↓ [1 hour sleep]
Run 3 (Hour 3): Grant SELECT on Object3  → 1 grant
    ↓ [1 hour sleep]
Run 4 (Hour 4): Grant SELECT on Object4  → 1 grant
    ↓ [1 hour sleep]
Run 5 (Hour 5): Grant SELECT on Object5-Object25 → 21 grants ⚠️ OUTLIER!
```

## Cleanup Options

### Cleanup Single Test Run
```bash
./cleanup_unique.sh config_20231223_143022.sh
```

### Cleanup All Test Runs
```bash
# Create a script to clean all
for config in config_*.sh; do
    ./cleanup_unique.sh "$config"
done
```

### Manual Cleanup
```bash
# List all test databases
mysql -u root -p -e "SHOW DATABASES LIKE 'outlier_grant_test_%';"

# List all test users
mysql -u root -p -e "SELECT user FROM mysql.user WHERE user LIKE 'grant_%';"

# Drop specific database
mysql -u root -p -e "DROP DATABASE outlier_grant_test_20231223_143022;"

# Drop specific users
mysql -u root -p -e "DROP USER 'grant_giver_20231223_143022'@'%';"
mysql -u root -p -e "DROP USER 'grant_receiver_20231223_143022'@'%';"
```

## Advantages of Unique Names

### 1. Multiple Learning Phases
Each test run establishes its own baseline:
- Test 1: Baseline for `grant_giver_20231223_140000`
- Test 2: Baseline for `grant_giver_20231223_150000`
- Test 3: Baseline for `grant_giver_20231223_160000`

### 2. No Interference
Tests don't interfere with each other:
- Different databases
- Different users
- Separate audit trails

### 3. Historical Analysis
Keep multiple test runs for comparison:
```bash
# Compare different test runs
ls -la config_*.sh
ls -la logs/grant_scenario_*
```

### 4. Parallel Execution
Run tests simultaneously:
```bash
# Start 3 tests at once
./setup_with_unique_names.sh && ./start_test_unique.sh config_*.sh &
sleep 60
./setup_with_unique_names.sh && ./start_test_unique.sh config_*.sh &
sleep 60
./setup_with_unique_names.sh && ./start_test_unique.sh config_*.sh &
```

## File Structure

```
outlier_massive_grant_case_mysql/
├── setup_with_unique_names.sh      # Setup with unique names
├── start_test_unique.sh            # Run test with config file
├── cleanup_unique.sh               # Cleanup specific test
├── config_20231223_140000.sh       # Config for test run 1
├── config_20231223_150000.sh       # Config for test run 2
├── config_20231223_160000.sh       # Config for test run 3
└── logs/
    ├── grant_scenario_20231223_140000_*.log
    ├── grant_scenario_20231223_150000_*.log
    ├── grant_scenario_20231223_160000_*.log
    ├── test_pid_20231223_140000.txt
    ├── test_pid_20231223_150000.txt
    └── test_pid_20231223_160000.txt
```

## Comparison: Standard vs Unique Names

| Feature | Standard Names | Unique Names |
|---------|---------------|--------------|
| Database Name | `outlier_grant_test` | `outlier_grant_test_YYYYMMDD_HHMMSS` |
| User Names | `grant_giver`, `grant_receiver` | `grant_giver_SUFFIX`, `grant_receiver_SUFFIX` |
| Multiple Runs | Conflicts occur | No conflicts |
| Parallel Tests | Not possible | Fully supported |
| Learning Phase | Single baseline | Multiple baselines |
| Cleanup | Simple | Per-test cleanup |

## Best Practices

### 1. For Learning Phase
Run 3-5 tests with unique names to establish multiple baselines:
```bash
for i in {1..5}; do
    ./setup_with_unique_names.sh
    CONFIG=$(ls -t config_*.sh | head -1)
    ./start_test_unique.sh "$CONFIG"
    sleep 300  # Wait 5 minutes between starts
done
```

### 2. For Outlier Detection Testing
Run tests with unique names to verify detection works across different users:
```bash
# Each test creates different user, but same pattern
# Outlier detection should catch the massive grant in each
```

### 3. For Cleanup
Keep config files until you're done with analysis:
```bash
# Don't delete config files immediately
# They're needed for cleanup and reference
```

## Troubleshooting

### Can't Find Config File
```bash
# List all config files
ls -la config_*.sh

# Use the most recent one
CONFIG=$(ls -t config_*.sh | head -1)
./start_test_unique.sh "$CONFIG"
```

### Too Many Test Runs
```bash
# Clean up old tests
for config in config_*.sh; do
    echo "Cleaning: $config"
    ./cleanup_unique.sh "$config"
done
```

### Check What's Running
```bash
# Show all test processes
ps aux | grep run_unique

# Show all test databases
mysql -u root -p -e "SHOW DATABASES LIKE 'outlier_grant_test_%';"
```

---

**Recommendation**: Use unique names for production-like testing where multiple learning phases are needed.
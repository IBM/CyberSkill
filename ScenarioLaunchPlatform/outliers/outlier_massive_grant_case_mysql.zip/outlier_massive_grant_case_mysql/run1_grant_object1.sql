-- FIRST RUN: Grant SELECT on Object1
-- This script should be run by grant_giver user
-- Run time: Hour 1

USE outlier_grant_test;

-- Grant SELECT privilege on Object1
GRANT SELECT ON outlier_grant_test.Object1 TO 'grant_receiver'@'%';
FLUSH PRIVILEGES;

SELECT 'RUN 1 COMPLETED: Granted SELECT on Object1 to grant_receiver' AS Status;
SELECT NOW() AS execution_time;

-- Made with Bob

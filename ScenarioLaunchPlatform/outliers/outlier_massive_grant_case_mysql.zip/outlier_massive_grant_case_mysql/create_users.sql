-- Create users for the grant test scenario
-- This script should be run as root user

-- Step 1: Create the user who will grant privileges (grant_giver)
DROP USER IF EXISTS 'grant_giver'@'%';
CREATE USER 'grant_giver'@'%' IDENTIFIED BY 'Mysqlpswd@123';

-- Step 2: Grant ALL privileges with GRANT OPTION to grant_giver
GRANT ALL PRIVILEGES ON *.* TO 'grant_giver'@'%' WITH GRANT OPTION;
FLUSH PRIVILEGES;

-- Step 3: Create the user who will receive grants (grant_receiver)
DROP USER IF EXISTS 'grant_receiver'@'%';
CREATE USER 'grant_receiver'@'%' IDENTIFIED BY 'Mysqlpswd@123';

-- Note: grant_receiver initially has no privileges
-- Privileges will be granted incrementally by grant_giver user

SELECT 'Users created successfully!' AS Status;
SELECT 'grant_giver: User with ALL privileges and GRANT OPTION' AS grant_giver_info;
SELECT 'grant_receiver: User with no initial privileges' AS grant_receiver_info;

-- Made with Bob

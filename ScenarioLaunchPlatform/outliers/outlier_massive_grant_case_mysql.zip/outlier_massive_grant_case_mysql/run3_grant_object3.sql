-- THIRD RUN: Grant SELECT on Object3
-- This script should be run by grant_giver user
-- Run time: Hour 3 (after 2 hours total sleep)

USE outlier_grant_test;

-- Grant SELECT privilege on Object3
GRANT SELECT ON outlier_grant_test.Object3 TO 'grant_receiver'@'%';
FLUSH PRIVILEGES;

SELECT 'RUN 3 COMPLETED: Granted SELECT on Object3 to grant_receiver' AS Status;
SELECT NOW() AS execution_time;

-- Made with Bob

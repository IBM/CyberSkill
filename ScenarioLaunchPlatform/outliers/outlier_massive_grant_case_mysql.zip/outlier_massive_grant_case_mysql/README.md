# MySQL Massive Grant Outlier Test Case

## Overview
This test case simulates a **massive grant anomaly** scenario where a user gradually grants privileges on individual objects over time, then suddenly grants privileges on 21 objects at once. This massive grant operation should trigger outlier detection in database activity monitoring systems.

## Scenario Description
- **Learning Phase**: Runs 1-4 establish a baseline where the `grant_giver` user grants SELECT privileges on one object per hour
- **Outlier Phase**: Run 5 executes a massive grant operation on 21 objects simultaneously, deviating significantly from the established baseline

## Test Pattern
```
Run 1 (Hour 1): Grant SELECT on Object1  → 1 grant
    ↓ [1 hour sleep]
Run 2 (Hour 2): Grant SELECT on Object2  → 1 grant
    ↓ [1 hour sleep]
Run 3 (Hour 3): Grant SELECT on Object3  → 1 grant
    ↓ [1 hour sleep]
Run 4 (Hour 4): Grant SELECT on Object4  → 1 grant
    ↓ [1 hour sleep]
Run 5 (Hour 5): Grant SELECT on Object5-Object25 → 21 grants ⚠️ OUTLIER!
```

## Prerequisites
- MySQL 5.7 or higher
- Root access to MySQL server
- Bash shell environment
- Approximately 4-5 hours for complete test execution

## Quick Start (Fully Automated)

### Step 1: Setup
Run the automated setup script:
```bash
cd outlier_massive_grant_case_mysql
./setup.sh
```

This will automatically:
- Create database `outlier_grant_test`
- Create 25 tables (Object1 through Object25)
- Create test users (`grant_giver` and `grant_receiver`)
- Verify all components

### Step 2: Run Test in Background
Execute the test in background (you can exit terminal):
```bash
./start_test.sh
```

This will:
- Start the test in background with `nohup`
- Allow you to safely exit the terminal
- Continue running for ~4 hours
- Save all output to logs

**OR** run in foreground (terminal must stay open):
```bash
./run_grant_scenario.sh
```

### Step 3: Check Test Status
Check if test is still running:
```bash
./check_status.sh
```

### Step 4: Cleanup (Optional)
Remove all test data:
```bash
./cleanup.sh
```

## What Gets Created

### Database Objects
- **Database**: `outlier_grant_test`
- **Tables**: 25 tables named `Object1` through `Object25`
- Each table contains sample data

### Users
- **grant_giver** (password: `Mysqlpswd@123`)
  - Has ALL PRIVILEGES with GRANT OPTION
  - Executes the grant operations
  
- **grant_receiver** (password: `Mysqlpswd@123`)
  - Initially has no privileges
  - Receives grants incrementally

## Monitoring the Test

### View Real-time Logs
```bash
tail -f logs/grant_scenario_*.log
```

### Check Grant Progress
```bash
# View all grants for grant_receiver
mysql -u root -p -e "SHOW GRANTS FOR 'grant_receiver'@'%';"

# Count total grants
mysql -u root -p -e "SELECT COUNT(*) FROM mysql.tables_priv WHERE User='grant_receiver';"
```

### Expected Results After Each Run
- **After Run 1**: 1 grant total (Object1)
- **After Run 2**: 2 grants total (Object1-2)
- **After Run 3**: 3 grants total (Object1-3)
- **After Run 4**: 4 grants total (Object1-4)
- **After Run 5**: 25 grants total (Object1-25) ← **OUTLIER**

## Outlier Detection Expectations

### Baseline Behavior (Runs 1-4)
- **Pattern**: 1 grant per hour
- **Frequency**: Consistent hourly intervals
- **Scope**: Single object per operation

### Anomalous Behavior (Run 5)
- **Pattern**: 21 grants in one operation
- **Deviation**: 2100% increase from baseline
- **Alert Trigger**: Massive privilege escalation

### Detection Criteria
A properly configured database activity monitoring system should detect:
1. **Volume Anomaly**: Sudden spike in grant operations (21× normal)
2. **Privilege Escalation**: Rapid expansion of user privileges
3. **Behavioral Change**: Deviation from established hourly pattern
4. **Risk Level**: High - potential insider threat or compromised account

## Files Description

| File | Purpose |
|------|---------|
| `setup.sh` | **Automated setup** - Creates database, tables, and users |
| `start_test.sh` | **Background launcher** - Starts test in background with nohup |
| `check_status.sh` | **Status checker** - Check if test is running and view progress |
| `run_grant_scenario.sh` | **Main test script** - Executes 5 runs with 1-hour sleeps |
| `cleanup.sh` | **Cleanup script** - Removes all test data |
| `setup_database_and_tables.sql` | SQL for database and table creation |
| `create_users.sql` | SQL for user creation |
| `run1_grant_object1.sql` | Run 1: Grant on Object1 |
| `run2_grant_object2.sql` | Run 2: Grant on Object2 |
| `run3_grant_object3.sql` | Run 3: Grant on Object3 |
| `run4_grant_object4.sql` | Run 4: Grant on Object4 |
| `run5_grant_massive_objects.sql` | Run 5: Massive grant on 21 objects |
| `README.md` | This documentation |

## Execution Timeline

| Time | Activity | Duration |
|------|----------|----------|
| T+0m | Run setup.sh | ~1 minute |
| T+1m | Start run_grant_scenario.sh | - |
| T+1m | Run 1 execution | ~1 second |
| T+1m-1h | Sleep interval | 1 hour |
| T+1h | Run 2 execution | ~1 second |
| T+1h-2h | Sleep interval | 1 hour |
| T+2h | Run 3 execution | ~1 second |
| T+2h-3h | Sleep interval | 1 hour |
| T+3h | Run 4 execution | ~1 second |
| T+3h-4h | Sleep interval | 1 hour |
| T+4h | Run 5 execution (OUTLIER) | ~1 second |
| **Total** | | **~4 hours 1 minute** |

## Troubleshooting

### Setup Issues
If setup fails:
```bash
# Check MySQL is running
systemctl status mysql

# Verify root access
mysql -u root -p -e "SELECT 1;"

# Re-run setup
./setup.sh
```

### Test Execution Issues
If test fails mid-execution:
```bash
# Check logs
cat logs/grant_scenario_*.log

# Verify grant_giver can connect
mysql -u grant_giver -pMysqlpswd@123 -e "SELECT 1;"

# Check current grants
mysql -u root -p -e "SHOW GRANTS FOR 'grant_receiver'@'%';"
```

### Cleanup Issues
If cleanup fails:
```bash
# Manual cleanup
mysql -u root -p << EOF
DROP USER IF EXISTS 'grant_giver'@'%';
DROP USER IF EXISTS 'grant_receiver'@'%';
DROP DATABASE IF EXISTS outlier_grant_test;
EOF

# Remove logs
rm -rf logs/
```

## Security Considerations

⚠️ **Warning**: This test creates users with powerful privileges.

- **Use only in test/development environments**
- Never run in production
- Remove test users immediately after testing
- Use strong passwords in production scenarios
- Monitor for unauthorized privilege escalations

## Use Cases

This test case is valuable for:
- Testing database activity monitoring (DAM) systems
- Validating outlier detection algorithms
- Training security teams on privilege escalation patterns
- Benchmarking anomaly detection thresholds
- Demonstrating insider threat scenarios

## Advanced Configuration

### Modify Sleep Duration
Edit `run_grant_scenario.sh` and change the sleep duration:
```bash
# Change from 1 hour to 30 minutes
sleep_with_countdown 0.5  # 0.5 hours = 30 minutes
```

### Change MySQL Credentials
Edit the configuration section in scripts:
```bash
MYSQL_HOST="localhost"
MYSQL_USER="grant_giver"
MYSQL_PASSWORD="Mysqlpswd@123"
```

### Adjust Number of Objects
Modify `run5_grant_massive_objects.sql` to grant on more/fewer objects.

## Support

For issues:
1. Check MySQL error logs: `/var/log/mysql/error.log`
2. Review script logs: `logs/grant_scenario_*.log`
3. Verify MySQL version: `mysql --version`
4. Ensure sufficient privileges for test users

---

**Test Case Version**: 1.0  
**Last Updated**: 2025-12-23  
**Database**: MySQL 5.7+  
**Test Type**: Massive Grant Outlier Detection  
**Automation**: Fully Automated
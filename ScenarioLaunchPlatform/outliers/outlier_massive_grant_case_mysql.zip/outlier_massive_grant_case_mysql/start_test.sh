#!/bin/bash

# Wrapper script to run the grant scenario in the background
# This allows you to exit the terminal and the test will continue running

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_DIR="$SCRIPT_DIR/logs"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
MAIN_LOG="$LOG_DIR/background_run_${TIMESTAMP}.log"

# Create logs directory
mkdir -p "$LOG_DIR"

echo "=========================================="
echo "Starting Grant Scenario Test in Background"
echo "=========================================="
echo ""
echo "The test will run for approximately 4 hours"
echo "You can safely exit the terminal"
echo ""
echo "Log file: $MAIN_LOG"
echo ""

# Run the script in background with nohup
nohup "$SCRIPT_DIR/run_grant_scenario.sh" > "$MAIN_LOG" 2>&1 &

PID=$!

echo "Process started with PID: $PID"
echo ""
echo "To monitor progress:"
echo "  tail -f $MAIN_LOG"
echo ""
echo "To check if still running:"
echo "  ps -p $PID"
echo ""
echo "To stop the test:"
echo "  kill $PID"
echo ""
echo "=========================================="

# Save PID to file for easy reference
echo $PID > "$LOG_DIR/test_pid.txt"
echo "PID saved to: $LOG_DIR/test_pid.txt"

# Made with Bob

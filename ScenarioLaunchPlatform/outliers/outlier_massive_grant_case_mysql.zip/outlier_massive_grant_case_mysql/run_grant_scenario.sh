#!/bin/bash

# Main orchestration script for Massive Grant Outlier Test
# This script runs 5 grant operations with 1-hour sleep intervals between each run
# The 5th run grants privileges on 21 objects at once to trigger outlier detection

# Configuration
MYSQL_HOST="localhost"
MYSQL_PORT="3306"
MYSQL_USER="grant_giver"
MYSQL_PASSWORD="Mysqlpswd@123"
LOG_DIR="./logs"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
LOG_FILE="${LOG_DIR}/grant_scenario_${TIMESTAMP}.log"

# Create log directory if it doesn't exist
mkdir -p "$LOG_DIR"

# Function to log messages
log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Function to execute SQL file
execute_sql() {
    local sql_file=$1
    local run_number=$2
    
    log_message "=========================================="
    log_message "Starting RUN $run_number"
    log_message "Executing: $sql_file"
    log_message "=========================================="
    
    MYSQL_PWD="$MYSQL_PASSWORD" mysql -u "$MYSQL_USER" < "$sql_file" 2>&1 | tee -a "$LOG_FILE"
    
    if [ $? -eq 0 ]; then
        log_message "RUN $run_number completed successfully"
    else
        log_message "ERROR: RUN $run_number failed"
        exit 1
    fi
}

# Function to sleep with countdown
sleep_with_countdown() {
    local hours=$1
    local seconds=$((hours * 3600))
    
    log_message "Sleeping for $hours hour(s) ($seconds seconds)..."
    log_message "Next run will start at: $(date -d "+$hours hours" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date -v+${hours}H '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo 'N/A')"
    
    # Sleep in 10-minute intervals to show progress
    local interval=600  # 10 minutes
    local elapsed=0
    
    while [ $elapsed -lt $seconds ]; do
        sleep $interval
        elapsed=$((elapsed + interval))
        local remaining=$((seconds - elapsed))
        local remaining_minutes=$((remaining / 60))
        log_message "Progress: $((elapsed / 60)) minutes elapsed, $remaining_minutes minutes remaining..."
    done
    
    log_message "Sleep completed. Proceeding to next run..."
}

# Main execution
log_message "=========================================="
log_message "MASSIVE GRANT OUTLIER TEST SCENARIO"
log_message "=========================================="
log_message "Start time: $(date)"
log_message "This test will run 5 grant operations with 1-hour intervals"
log_message "Total estimated duration: 4 hours"
log_message ""

# Verify grant_giver user can connect
log_message "Verifying database connection..."
MYSQL_PWD="$MYSQL_PASSWORD" mysql -u "$MYSQL_USER" -e "SELECT 'Connection successful' AS Status;" 2>&1 | tee -a "$LOG_FILE"

if [ $? -ne 0 ]; then
    log_message "ERROR: Cannot connect to MySQL. Please check credentials and ensure grant_giver user exists."
    exit 1
fi

log_message "Connection verified successfully"
log_message ""

# RUN 1: Grant on Object1
execute_sql "run1_grant_object1.sql" 1
sleep_with_countdown 1

# RUN 2: Grant on Object2
execute_sql "run2_grant_object2.sql" 2
sleep_with_countdown 1

# RUN 3: Grant on Object3
execute_sql "run3_grant_object3.sql" 3
sleep_with_countdown 1

# RUN 4: Grant on Object4
execute_sql "run4_grant_object4.sql" 4
sleep_with_countdown 1

# RUN 5: MASSIVE GRANT on Object5-Object25 (21 objects)
log_message "=========================================="
log_message "FINAL RUN: MASSIVE GRANT OPERATION"
log_message "This run will grant privileges on 21 objects"
log_message "This should trigger outlier detection!"
log_message "=========================================="
execute_sql "run5_grant_massive_objects.sql" 5

# Summary
log_message ""
log_message "=========================================="
log_message "TEST SCENARIO COMPLETED"
log_message "=========================================="
log_message "End time: $(date)"
log_message "Total grants executed:"
log_message "  - Run 1: 1 grant (Object1)"
log_message "  - Run 2: 1 grant (Object2)"
log_message "  - Run 3: 1 grant (Object3)"
log_message "  - Run 4: 1 grant (Object4)"
log_message "  - Run 5: 21 grants (Object5-Object25) <- OUTLIER"
log_message ""
log_message "Log file: $LOG_FILE"
log_message "=========================================="

# Made with Bob

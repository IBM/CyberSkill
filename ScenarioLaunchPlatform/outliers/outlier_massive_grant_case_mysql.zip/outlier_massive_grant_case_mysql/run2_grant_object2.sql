-- SECOND RUN: Grant SELECT on Object2
-- This script should be run by grant_giver user
-- Run time: Hour 2 (after 1 hour sleep)

USE outlier_grant_test;

-- Grant SELECT privilege on Object2
GRANT SELECT ON outlier_grant_test.Object2 TO 'grant_receiver'@'%';
FLUSH PRIVILEGES;

SELECT 'RUN 2 COMPLETED: Granted SELECT on Object2 to grant_receiver' AS Status;
SELECT NOW() AS execution_time;

-- Made with Bob

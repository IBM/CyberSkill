#!/bin/bash

# Automated cleanup script for Massive Grant Outlier Test
# This script removes all test data, users, and logs

# Configuration
MYSQL_ROOT_PASSWORD="Mysqlpswd@123"
MYSQL_HOST="localhost"
MYSQL_PORT="3306"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored messages
print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_info() {
    echo -e "${YELLOW}[INFO]${NC} $1"
}

# Function to display MySQL connection info
show_connection_info() {
    echo ""
    echo "=========================================="
    echo "MySQL Connection Details"
    echo "=========================================="
    echo "Host: $MYSQL_HOST"
    echo "User: root"
    echo "Password: $MYSQL_ROOT_PASSWORD"
    echo ""
}

# Main cleanup
echo "=========================================="
echo "MASSIVE GRANT OUTLIER TEST - CLEANUP"
echo "=========================================="
echo ""
echo "This will remove:"
echo "  - Database: outlier_grant_test"
echo "  - Users: grant_giver, grant_receiver"
echo "  - Logs directory"
echo ""
read -p "Are you sure you want to continue? (yes/no): " CONFIRM

if [ "$CONFIRM" != "yes" ]; then
    print_info "Cleanup cancelled"
    exit 0
fi

# Show connection info
show_connection_info

# Test connection
print_info "Testing MySQL connection..."
MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -u root -e "SELECT 1;" > /dev/null 2>&1
if [ $? -ne 0 ]; then
    print_error "Cannot connect to MySQL. Please check your password and try again."
    exit 1
fi
print_success "MySQL connection successful"

# Drop users
print_info "Removing test users..."
MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -u root -e "DROP USER IF EXISTS 'grant_giver'@'%';" 2>/dev/null
MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -u root -e "DROP USER IF EXISTS 'grant_receiver'@'%';" 2>/dev/null
print_success "Test users removed"

# Drop database
print_info "Removing test database..."
MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -u root -e "DROP DATABASE IF EXISTS outlier_grant_test;" 2>/dev/null
print_success "Test database removed"

# Remove logs
if [ -d "logs" ]; then
    print_info "Removing logs directory..."
    rm -rf logs
    print_success "Logs directory removed"
fi

echo ""
echo "=========================================="
echo "CLEANUP COMPLETED SUCCESSFULLY"
echo "=========================================="
echo ""
echo "All test data has been removed:"
echo "  ✓ Database dropped"
echo "  ✓ Users removed"
echo "  ✓ Logs deleted"
echo "=========================================="

# Made with Bob

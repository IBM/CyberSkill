#!/bin/bash

# Automated setup script with unique names for each run
# This allows multiple test runs on the same system without conflicts

# Generate unique suffix based on timestamp
UNIQUE_SUFFIX=$(date +%Y%m%d_%H%M%S)

# Configuration
MYSQL_ROOT_PASSWORD="Mysqlpswd@123"
MYSQL_HOST="localhost"
MYSQL_PORT="3306"

# Unique names for this run
DB_NAME="outlier_grant_test_${UNIQUE_SUFFIX}"
GRANT_GIVER="grant_giver_${UNIQUE_SUFFIX}"
GRANT_RECEIVER="grant_receiver_${UNIQUE_SUFFIX}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored messages
print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_info() {
    echo -e "${YELLOW}[INFO]${NC} $1"
}

print_highlight() {
    echo -e "${BLUE}[UNIQUE]${NC} $1"
}

# Function to display MySQL connection info
show_connection_info() {
    echo ""
    echo "=========================================="
    echo "MySQL Connection Details"
    echo "=========================================="
    echo "Host: $MYSQL_HOST"
    echo "User: root"
    echo "Password: $MYSQL_ROOT_PASSWORD"
    echo ""
}

# Function to test MySQL connection
test_mysql_connection() {
    # Try without host first (uses socket)
    MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -u root -e "SELECT 1;" > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        return 0
    fi
    # Try with host and port
    MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -h "$MYSQL_HOST" -P "$MYSQL_PORT" -u root -e "SELECT 1;" > /dev/null 2>&1
    return $?
}

# Main setup
echo "=========================================="
echo "MASSIVE GRANT OUTLIER TEST - AUTOMATED SETUP"
echo "WITH UNIQUE NAMES"
echo "=========================================="
echo ""

print_highlight "Unique suffix for this run: $UNIQUE_SUFFIX"
print_highlight "Database name: $DB_NAME"
print_highlight "Grant giver user: $GRANT_GIVER"
print_highlight "Grant receiver user: $GRANT_RECEIVER"
echo ""

# Show connection info
show_connection_info

# Test connection
print_info "Testing MySQL connection..."
if ! test_mysql_connection; then
    print_error "Cannot connect to MySQL. Please check your password and try again."
    exit 1
fi
print_success "MySQL connection successful"

# Step 1: Create database and tables with unique name
print_info "Creating database and tables..."
MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -u root << EOF
-- Create database with unique name
CREATE DATABASE IF NOT EXISTS ${DB_NAME};

USE ${DB_NAME};

-- Create 25 tables (Object1 to Object25)
$(for i in {1..25}; do
    echo "CREATE TABLE IF NOT EXISTS Object${i} (
    id INT PRIMARY KEY AUTO_INCREMENT,
    data VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);"
    echo "INSERT INTO Object${i} (data) VALUES ('Sample data for Object${i}');"
done)

SELECT 'Database and tables created successfully!' AS Status;
EOF

if [ $? -eq 0 ]; then
    print_success "Database and 25 tables created"
else
    print_error "Failed to create database and tables"
    exit 1
fi

# Step 2: Create users with unique names
print_info "Creating test users (${GRANT_GIVER} and ${GRANT_RECEIVER})..."
MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -u root << EOF
-- Create the user who will grant privileges
DROP USER IF EXISTS '${GRANT_GIVER}'@'%';
CREATE USER '${GRANT_GIVER}'@'%' IDENTIFIED BY 'Mysqlpswd@123';

-- Grant ALL privileges with GRANT OPTION
GRANT ALL PRIVILEGES ON *.* TO '${GRANT_GIVER}'@'%' WITH GRANT OPTION;
FLUSH PRIVILEGES;

-- Create the user who will receive grants
DROP USER IF EXISTS '${GRANT_RECEIVER}'@'%';
CREATE USER '${GRANT_RECEIVER}'@'%' IDENTIFIED BY 'Mysqlpswd@123';

SELECT 'Users created successfully!' AS Status;
EOF

if [ $? -eq 0 ]; then
    print_success "Test users created successfully"
else
    print_error "Failed to create users"
    exit 1
fi

# Step 3: Verify setup
print_info "Verifying setup..."

# Check database
DB_EXISTS=$(MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -u root -e "SHOW DATABASES LIKE '${DB_NAME}';" 2>/dev/null | grep -c "${DB_NAME}")
if [ "$DB_EXISTS" -ge 1 ]; then
    print_success "Database '${DB_NAME}' verified"
else
    print_error "Database verification failed"
    exit 1
fi

# Check tables
TABLE_COUNT=$(MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -u root -e "USE ${DB_NAME}; SHOW TABLES;" 2>/dev/null | grep -c "Object")
if [ "$TABLE_COUNT" -ge 25 ]; then
    print_success "All 25 tables verified (found $TABLE_COUNT)"
else
    print_error "Expected 25 tables, found $TABLE_COUNT"
    exit 1
fi

# Check users
USER_COUNT=$(MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -u root -e "SELECT COUNT(*) as cnt FROM mysql.user WHERE user IN ('${GRANT_GIVER}', '${GRANT_RECEIVER}');" 2>/dev/null | tail -1)
if [ "$USER_COUNT" -ge 2 ]; then
    print_success "Both test users verified (found $USER_COUNT)"
else
    print_error "User verification failed (found $USER_COUNT users)"
    exit 1
fi

# Create logs directory
mkdir -p logs

# Save configuration for the test run
CONFIG_FILE="config_${UNIQUE_SUFFIX}.sh"
cat > "$CONFIG_FILE" << EOF
# Configuration for test run: $UNIQUE_SUFFIX
export DB_NAME="${DB_NAME}"
export GRANT_GIVER="${GRANT_GIVER}"
export GRANT_RECEIVER="${GRANT_RECEIVER}"
export UNIQUE_SUFFIX="${UNIQUE_SUFFIX}"
export MYSQL_PASSWORD="Mysqlpswd@123"
EOF

print_success "Configuration saved to: $CONFIG_FILE"

echo ""
echo "=========================================="
echo "SETUP COMPLETED SUCCESSFULLY"
echo "=========================================="
echo ""
echo "Summary:"
echo "  ✓ Database: ${DB_NAME}"
echo "  ✓ Tables: Object1 through Object25 (25 total)"
echo "  ✓ Users: ${GRANT_GIVER}, ${GRANT_RECEIVER}"
echo "  ✓ Config file: ${CONFIG_FILE}"
echo ""
echo "Next Steps:"
echo "  Run the test scenario with:"
echo "  ./start_test_unique.sh ${CONFIG_FILE}"
echo ""
echo "  This will execute 5 grant operations with 1-hour intervals"
echo "  Total duration: ~4 hours"
echo "=========================================="

# Made with Bob

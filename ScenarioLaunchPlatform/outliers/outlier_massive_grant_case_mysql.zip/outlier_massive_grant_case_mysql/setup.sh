#!/bin/bash

# Automated setup script for Massive Grant Outlier Test
# This script sets up everything automatically

# Configuration
MYSQL_ROOT_PASSWORD="Mysqlpswd@123"
MYSQL_HOST="localhost"
MYSQL_PORT="3306"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored messages
print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_info() {
    echo -e "${YELLOW}[INFO]${NC} $1"
}

# Function to display MySQL connection info
show_connection_info() {
    echo ""
    echo "=========================================="
    echo "MySQL Connection Details"
    echo "=========================================="
    echo "Host: $MYSQL_HOST"
    echo "User: root"
    echo "Password: $MYSQL_ROOT_PASSWORD"
    echo ""
}

# Function to test MySQL connection
test_mysql_connection() {
    # Try without host first (uses socket)
    MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -u root -e "SELECT 1;" > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        return 0
    fi
    # Try with host and port
    MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -h "$MYSQL_HOST" -P "$MYSQL_PORT" -u root -e "SELECT 1;" > /dev/null 2>&1
    return $?
}

# Main setup
echo "=========================================="
echo "MASSIVE GRANT OUTLIER TEST - AUTOMATED SETUP"
echo "=========================================="
echo ""

# Show connection info
show_connection_info

# Test connection
print_info "Testing MySQL connection..."
if ! test_mysql_connection; then
    print_error "Cannot connect to MySQL. Please check your password and try again."
    exit 1
fi
print_success "MySQL connection successful"

# Step 1: Create database and tables
print_info "Creating database and tables..."
MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -u root < setup_database_and_tables.sql
if [ $? -eq 0 ]; then
    print_success "Database and 25 tables created"
else
    print_error "Failed to create database and tables"
    exit 1
fi

# Step 2: Create users
print_info "Creating test users (grant_giver and grant_receiver)..."
MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -u root < create_users.sql
if [ $? -eq 0 ]; then
    print_success "Test users created successfully"
else
    print_error "Failed to create users"
    exit 1
fi

# Step 3: Verify setup
print_info "Verifying setup..."

# Check database
DB_EXISTS=$(MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -u root -e "SHOW DATABASES LIKE 'outlier_grant_test';" 2>/dev/null | grep -c "outlier_grant_test")
if [ "$DB_EXISTS" -ge 1 ]; then
    print_success "Database 'outlier_grant_test' verified"
else
    print_error "Database verification failed"
    exit 1
fi

# Check tables
TABLE_COUNT=$(MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -u root -e "USE outlier_grant_test; SHOW TABLES;" 2>/dev/null | grep -c "Object")
if [ "$TABLE_COUNT" -ge 25 ]; then
    print_success "All 25 tables verified (found $TABLE_COUNT)"
else
    print_error "Expected 25 tables, found $TABLE_COUNT"
    exit 1
fi

# Check users
USER_COUNT=$(MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -u root -e "SELECT COUNT(*) as cnt FROM mysql.user WHERE user IN ('grant_giver', 'grant_receiver');" 2>/dev/null | tail -1)
if [ "$USER_COUNT" -ge 2 ]; then
    print_success "Both test users verified (found $USER_COUNT)"
else
    print_error "User verification failed (found $USER_COUNT users)"
    exit 1
fi

# Create logs directory
mkdir -p logs

echo ""
echo "=========================================="
echo "SETUP COMPLETED SUCCESSFULLY"
echo "=========================================="
echo ""
echo "Summary:"
echo "  ✓ Database: outlier_grant_test"
echo "  ✓ Tables: Object1 through Object25 (25 total)"
echo "  ✓ Users: grant_giver, grant_receiver"
echo ""
echo "Next Steps:"
echo "  Run the test scenario with:"
echo "  ./run_grant_scenario.sh"
echo ""
echo "  This will execute 5 grant operations with 1-hour intervals"
echo "  Total duration: ~4 hours"
echo "=========================================="

# Made with Bob

#!/bin/bash

# Wrapper script to run the grant scenario with unique names in the background

# Check if config file is provided
if [ $# -eq 0 ]; then
    echo "Error: Configuration file required"
    echo "Usage: $0 <config_file>"
    echo ""
    echo "Example:"
    echo "  ./start_test_unique.sh config_20231223_120000.sh"
    exit 1
fi

CONFIG_FILE="$1"

# Check if config file exists
if [ ! -f "$CONFIG_FILE" ]; then
    echo "Error: Configuration file not found: $CONFIG_FILE"
    exit 1
fi

# Load configuration
source "$CONFIG_FILE"

# Verify required variables
if [ -z "$DB_NAME" ] || [ -z "$GRANT_GIVER" ] || [ -z "$GRANT_RECEIVER" ]; then
    echo "Error: Invalid configuration file. Missing required variables."
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_DIR="$SCRIPT_DIR/logs"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
MAIN_LOG="$LOG_DIR/grant_scenario_${UNIQUE_SUFFIX}_${TIMESTAMP}.log"

# Create logs directory
mkdir -p "$LOG_DIR"

echo "=========================================="
echo "Starting Grant Scenario Test in Background"
echo "WITH UNIQUE NAMES"
echo "=========================================="
echo ""
echo "Configuration:"
echo "  Database: $DB_NAME"
echo "  Grant Giver: $GRANT_GIVER"
echo "  Grant Receiver: $GRANT_RECEIVER"
echo "  Unique Suffix: $UNIQUE_SUFFIX"
echo ""
echo "The test will run for approximately 4 hours"
echo "You can safely exit the terminal"
echo ""
echo "Log file: $MAIN_LOG"
echo ""

# Create a temporary script that will run with the unique configuration
TEMP_SCRIPT="$LOG_DIR/run_unique_${UNIQUE_SUFFIX}.sh"
cat > "$TEMP_SCRIPT" << 'EOFSCRIPT'
#!/bin/bash

# Load configuration
source "$1"

MYSQL_HOST="localhost"
MYSQL_USER="$GRANT_GIVER"
MYSQL_PASSWORD="Mysqlpswd@123"
LOG_FILE="$2"

# Function to log messages
log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Function to execute SQL with unique names
execute_grant_sql() {
    local object_name=$1
    local run_number=$2
    
    log_message "=========================================="
    log_message "Starting RUN $run_number"
    log_message "Granting SELECT on ${DB_NAME}.${object_name} to ${GRANT_RECEIVER}"
    log_message "=========================================="
    
    MYSQL_PWD="$MYSQL_PASSWORD" mysql -u "$MYSQL_USER" << EOF 2>&1 | tee -a "$LOG_FILE"
USE ${DB_NAME};
GRANT SELECT ON ${DB_NAME}.${object_name} TO '${GRANT_RECEIVER}'@'%';
FLUSH PRIVILEGES;
SELECT 'RUN $run_number COMPLETED: Granted SELECT on ${object_name} to ${GRANT_RECEIVER}' AS Status;
SELECT NOW() AS execution_time;
EOF
    
    if [ $? -eq 0 ]; then
        log_message "RUN $run_number completed successfully"
    else
        log_message "ERROR: RUN $run_number failed"
        exit 1
    fi
}

# Function to execute massive grant
execute_massive_grant() {
    local run_number=$1
    
    log_message "=========================================="
    log_message "FINAL RUN: MASSIVE GRANT OPERATION"
    log_message "This run will grant privileges on 21 objects"
    log_message "This should trigger outlier detection!"
    log_message "=========================================="
    
    MYSQL_PWD="$MYSQL_PASSWORD" mysql -u "$MYSQL_USER" << EOF 2>&1 | tee -a "$LOG_FILE"
USE ${DB_NAME};
$(for i in {5..25}; do
    echo "GRANT SELECT ON ${DB_NAME}.Object${i} TO '${GRANT_RECEIVER}'@'%';"
done)
FLUSH PRIVILEGES;
SELECT 'RUN $run_number COMPLETED (MASSIVE GRANT): Granted SELECT on 21 objects (Object5-Object25) to ${GRANT_RECEIVER}' AS Status;
SELECT 'This massive grant operation should trigger outlier detection!' AS Alert;
SELECT NOW() AS execution_time;
EOF
    
    if [ $? -eq 0 ]; then
        log_message "RUN $run_number completed successfully"
    else
        log_message "ERROR: RUN $run_number failed"
        exit 1
    fi
}

# Function to sleep with countdown
sleep_with_countdown() {
    local hours=$1
    local seconds=$((hours * 3600))
    
    log_message "Sleeping for $hours hour(s) ($seconds seconds)..."
    
    # Sleep in 10-minute intervals
    local interval=600
    local elapsed=0
    
    while [ $elapsed -lt $seconds ]; do
        sleep $interval
        elapsed=$((elapsed + interval))
        local remaining=$((seconds - elapsed))
        local remaining_minutes=$((remaining / 60))
        log_message "Progress: $((elapsed / 60)) minutes elapsed, $remaining_minutes minutes remaining..."
    done
    
    log_message "Sleep completed. Proceeding to next run..."
}

# Main execution
log_message "=========================================="
log_message "MASSIVE GRANT OUTLIER TEST SCENARIO"
log_message "WITH UNIQUE NAMES"
log_message "=========================================="
log_message "Database: $DB_NAME"
log_message "Grant Giver: $GRANT_GIVER"
log_message "Grant Receiver: $GRANT_RECEIVER"
log_message "Start time: $(date)"
log_message "This test will run 5 grant operations with 1-hour intervals"
log_message "Total estimated duration: 4 hours"
log_message ""

# Verify connection
log_message "Verifying database connection..."
MYSQL_PWD="$MYSQL_PASSWORD" mysql -u "$MYSQL_USER" -e "SELECT 'Connection successful' AS Status;" 2>&1 | tee -a "$LOG_FILE"

if [ $? -ne 0 ]; then
    log_message "ERROR: Cannot connect to MySQL."
    exit 1
fi

log_message "Connection verified successfully"
log_message ""

# RUN 1: Grant on Object1
execute_grant_sql "Object1" 1
sleep_with_countdown 1

# RUN 2: Grant on Object2
execute_grant_sql "Object2" 2
sleep_with_countdown 1

# RUN 3: Grant on Object3
execute_grant_sql "Object3" 3
sleep_with_countdown 1

# RUN 4: Grant on Object4
execute_grant_sql "Object4" 4
sleep_with_countdown 1

# RUN 5: MASSIVE GRANT on Object5-Object25 (21 objects)
execute_massive_grant 5

# Summary
log_message ""
log_message "=========================================="
log_message "TEST SCENARIO COMPLETED"
log_message "=========================================="
log_message "End time: $(date)"
log_message "Database: $DB_NAME"
log_message "Total grants executed:"
log_message "  - Run 1: 1 grant (Object1)"
log_message "  - Run 2: 1 grant (Object2)"
log_message "  - Run 3: 1 grant (Object3)"
log_message "  - Run 4: 1 grant (Object4)"
log_message "  - Run 5: 21 grants (Object5-Object25) <- OUTLIER"
log_message ""
log_message "Log file: $LOG_FILE"
log_message "=========================================="
EOFSCRIPT

chmod +x "$TEMP_SCRIPT"

# Run the script in background with nohup
nohup "$TEMP_SCRIPT" "$CONFIG_FILE" "$MAIN_LOG" > "$LOG_DIR/background_${UNIQUE_SUFFIX}_${TIMESTAMP}.log" 2>&1 &

PID=$!

echo "Process started with PID: $PID"
echo ""
echo "To monitor progress:"
echo "  tail -f $MAIN_LOG"
echo ""
echo "To check if still running:"
echo "  ps -p $PID"
echo ""
echo "To stop the test:"
echo "  kill $PID"
echo ""
echo "=========================================="

# Save PID to file for easy reference
echo $PID > "$LOG_DIR/test_pid_${UNIQUE_SUFFIX}.txt"
echo "PID saved to: $LOG_DIR/test_pid_${UNIQUE_SUFFIX}.txt"

# Made with Bob

#!/bin/bash

# Script to check the status of the running test

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_DIR="$SCRIPT_DIR/logs"
PID_FILE="$LOG_DIR/test_pid.txt"

echo "=========================================="
echo "Grant Scenario Test Status"
echo "=========================================="
echo ""

# Check if PID file exists
if [ ! -f "$PID_FILE" ]; then
    echo "No test is currently running (PID file not found)"
    echo ""
    echo "To start the test, run:"
    echo "  ./start_test.sh"
    exit 0
fi

# Read PID
PID=$(cat "$PID_FILE")

# Check if process is running
if ps -p $PID > /dev/null 2>&1; then
    echo "✓ Test is RUNNING"
    echo "  PID: $PID"
    echo ""
    
    # Show latest log file
    LATEST_LOG=$(ls -t "$LOG_DIR"/grant_scenario_*.log 2>/dev/null | head -1)
    if [ -n "$LATEST_LOG" ]; then
        echo "Latest log file: $LATEST_LOG"
        echo ""
        echo "Last 10 lines of log:"
        echo "----------------------------------------"
        tail -10 "$LATEST_LOG"
        echo "----------------------------------------"
        echo ""
        echo "To view full log:"
        echo "  tail -f $LATEST_LOG"
    fi
    
    # Show background log if exists
    BG_LOG=$(ls -t "$LOG_DIR"/background_run_*.log 2>/dev/null | head -1)
    if [ -n "$BG_LOG" ]; then
        echo ""
        echo "Background log: $BG_LOG"
        echo "To view background log:"
        echo "  tail -f $BG_LOG"
    fi
else
    echo "✗ Test is NOT running"
    echo "  Last PID was: $PID"
    echo ""
    
    # Check if there are any logs
    LATEST_LOG=$(ls -t "$LOG_DIR"/grant_scenario_*.log 2>/dev/null | head -1)
    if [ -n "$LATEST_LOG" ]; then
        echo "Last log file: $LATEST_LOG"
        echo ""
        echo "Last 20 lines of log:"
        echo "----------------------------------------"
        tail -20 "$LATEST_LOG"
        echo "----------------------------------------"
    fi
    
    echo ""
    echo "To start a new test, run:"
    echo "  ./start_test.sh"
fi

echo ""
echo "=========================================="

# Made with Bob

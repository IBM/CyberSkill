-- FIFTH RUN (FINAL): Grant SELECT on remaining 21 objects (Object5 to Object25)
-- This script should be run by grant_giver user
-- Run time: Hour 5 (after 4 hours total sleep)
-- This is the MASSIVE GRANT run that should trigger outlier detection

USE outlier_grant_test;

-- Grant SELECT privileges on Object5 to Object25 (21 objects in one run)
GRANT SELECT ON outlier_grant_test.Object5 TO 'grant_receiver'@'%';
GRANT SELECT ON outlier_grant_test.Object6 TO 'grant_receiver'@'%';
GRANT SELECT ON outlier_grant_test.Object7 TO 'grant_receiver'@'%';
GRANT SELECT ON outlier_grant_test.Object8 TO 'grant_receiver'@'%';
GRANT SELECT ON outlier_grant_test.Object9 TO 'grant_receiver'@'%';
GRANT SELECT ON outlier_grant_test.Object10 TO 'grant_receiver'@'%';
GRANT SELECT ON outlier_grant_test.Object11 TO 'grant_receiver'@'%';
GRANT SELECT ON outlier_grant_test.Object12 TO 'grant_receiver'@'%';
GRANT SELECT ON outlier_grant_test.Object13 TO 'grant_receiver'@'%';
GRANT SELECT ON outlier_grant_test.Object14 TO 'grant_receiver'@'%';
GRANT SELECT ON outlier_grant_test.Object15 TO 'grant_receiver'@'%';
GRANT SELECT ON outlier_grant_test.Object16 TO 'grant_receiver'@'%';
GRANT SELECT ON outlier_grant_test.Object17 TO 'grant_receiver'@'%';
GRANT SELECT ON outlier_grant_test.Object18 TO 'grant_receiver'@'%';
GRANT SELECT ON outlier_grant_test.Object19 TO 'grant_receiver'@'%';
GRANT SELECT ON outlier_grant_test.Object20 TO 'grant_receiver'@'%';
GRANT SELECT ON outlier_grant_test.Object21 TO 'grant_receiver'@'%';
GRANT SELECT ON outlier_grant_test.Object22 TO 'grant_receiver'@'%';
GRANT SELECT ON outlier_grant_test.Object23 TO 'grant_receiver'@'%';
GRANT SELECT ON outlier_grant_test.Object24 TO 'grant_receiver'@'%';
GRANT SELECT ON outlier_grant_test.Object25 TO 'grant_receiver'@'%';

FLUSH PRIVILEGES;

SELECT 'RUN 5 COMPLETED (MASSIVE GRANT): Granted SELECT on 21 objects (Object5-Object25) to grant_receiver' AS Status;
SELECT 'This massive grant operation should trigger outlier detection!' AS Alert;
SELECT NOW() AS execution_time;

-- Made with Bob

-- FOURTH RUN: Grant SELECT on Object4
-- This script should be run by grant_giver user
-- Run time: Hour 4 (after 3 hours total sleep)

USE outlier_grant_test;

-- Grant SELECT privilege on Object4
GRANT SELECT ON outlier_grant_test.Object4 TO 'grant_receiver'@'%';
FLUSH PRIVILEGES;

SELECT 'RUN 4 COMPLETED: Granted SELECT on Object4 to grant_receiver' AS Status;
SELECT NOW() AS execution_time;

-- Made with Bob

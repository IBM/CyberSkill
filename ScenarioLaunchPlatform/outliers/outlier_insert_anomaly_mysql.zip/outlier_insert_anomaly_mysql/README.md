# MySQL INSERT Command Anomaly Detection Test

## Overview
This script simulates an INSERT command anomaly pattern to test database security monitoring systems. It establishes a baseline of normal data insertion activity, then creates a spike that should trigger anomaly detection for potential data injection attacks or bulk data loading anomalies.

## Pattern
- **Hours 1-4**: 50 INSERT commands per hour (baseline behavior)
- **Hour 5**: 1001 INSERT commands (anomaly spike - 20x increase)
- **Total**: 1201 INSERT commands over 5 hours

## Features
- ✅ Creates unique database and user for each run (timestamped)
- ✅ Automatic cleanup isolation (each run is independent)
- ✅ Varied INSERT queries for realistic patterns
- ✅ Progress tracking and detailed logging
- ✅ Foreground or background execution modes
- ✅ Proper error handling with exit code tracking
- ✅ Statistics tracking (record counts, categories, amounts)

## Prerequisites
- MySQL Server 5.7 or higher
- MySQL client installed
- **Root access** (required for auto-creating database and user)
- Sufficient server resources to handle 205K+ queries
- Time: ~5 hours for full execution
- **Enable Demo Mode** - Ensure demo mode is enabled in your GDP system before running the test

## Usage

### Background Mode
```bash
./run_timed_inserts_background.sh <host> <port> <root_password> background
```

Example:
```bash
./run_timed_inserts_background.sh localhost 3306 MyRootPass123 bg
```

## What It Does

### 1. Setup Phase
- Creates unique database: `insert_db_<timestamp>`
- Creates unique user: `insert_user_<timestamp>`
- Grants all privileges to the user on the database
- Creates test table with multiple columns and indexes

### 2. Execution Phase

**Hours 1-4 (Baseline):**
- Executes 50 INSERT commands per hour
- Varies INSERT types:
  - Simple single-row inserts
  - Inserts with different categories
  - Inserts with NULL values
  - Inserts with computed values
  - Multi-row batch inserts (3 rows at once)

**Hour 5 (Anomaly Spike):**
- Executes 1001 INSERT commands
- Same variety of INSERT types
- Should trigger anomaly detection

### 3. INSERT Query Types
The script uses 5 different INSERT patterns:

1. **Simple INSERT**:
```sql
INSERT INTO table (record_number, data, category, amount)
VALUES (1, 'Data for record 1', 'category_A', 1.50);
```

2. **Category-based INSERT**:
```sql
INSERT INTO table (record_number, data, category, amount, status)
VALUES (2, 'Category 2 data', 'category_2', 4.00, 'pending');
```

3. **Minimal INSERT with NULLs**:
```sql
INSERT INTO table (record_number, data, category)
VALUES (3, 'Minimal data 3', NULL);
```

4. **Computed values INSERT**:
```sql
INSERT INTO table (record_number, data, category, amount, status)
VALUES (4, CONCAT('Generated data ', NOW()), 'category_B', RAND() * 1000, 'completed');
```

5. **Multi-row batch INSERT**:
```sql
INSERT INTO table (record_number, data, category, amount) VALUES
(5, 'Batch insert row 1', 'category_C', 2.50),
(10005, 'Batch insert row 2', 'category_C', 3.75),
(20005, 'Batch insert row 3', 'category_C', 5.00);
```

## Monitoring

### Check if running (background mode)
```bash
ps aux | grep run_timed_inserts_background.sh
```

### Monitor progress
```bash
tail -f logs/timed_inserts_background_<timestamp>.log
```

### Stop execution
```bash
pkill -f run_timed_inserts_background.sh
```

## Logs
All logs are stored in the `logs/` directory:
- `timed_inserts_<timestamp>.log` - Main execution log
- `timed_inserts_background_<timestamp>.log` - Background execution log
- `inserts_hour_<N>_<timestamp>.log` - Individual hour logs with statistics
- `timed_inserts_pid_<timestamp>.txt` - Process ID file

## Expected Detection
Security monitoring systems should detect:
- **INSERT Command Anomaly**: 1001 inserts in hour 5 vs 50 in previous hours
- **Volume Spike**: 20x increase in data insertion activity
- **Behavioral Change**: Sudden surge in data creation operations
- **Potential Threats**:
  - Bulk data injection attack
  - Unauthorized mass data loading
  - Data exfiltration preparation
  - Database flooding/DoS attempt

## Database Objects Created
- Database: `insert_db_<timestamp>`
- User: `insert_user_<timestamp>`
- Table: `insert_test_data`
  - Columns: id, record_number, data, category, amount, status, created_at
  - Indexes on: record_number, category, status
  - Auto-increment primary key

## Statistics Tracked
Each hour logs:
- Total records inserted
- Distinct categories
- Distinct statuses
- Min/Max/Average amounts
- Execution duration

## Cleanup
Each run creates isolated resources with unique timestamps. To clean up:

```bash
# List all test databases
mysql -uroot -p -e "SHOW DATABASES LIKE 'insert_db_%';"

# Drop specific database
mysql -uroot -p -e "DROP DATABASE insert_db_<timestamp>;"

# Drop specific user
mysql -uroot -p -e "DROP USER 'insert_user_<timestamp>'@'%';"
```

## Troubleshooting

### Connection Issues
- Verify MySQL is running: `systemctl status mysql`
- Check host and port: `mysql -h<host> -P<port> -uroot -p`
- Verify root password

### Permission Issues
- Ensure root user has CREATE DATABASE and CREATE USER privileges
- Check firewall rules if connecting remotely

### Script Issues
- Check logs in `logs/` directory
- Verify script is executable: `chmod +x run_timed_inserts_background.sh`
- Ensure bash is available: `which bash`
- Ensure bc is installed: `which bc` (for decimal calculations)

### Performance Issues
- Large INSERT volumes may impact database performance
- Monitor disk space during execution
- Check MySQL max_allowed_packet setting for large inserts

## Notes
- Each execution creates a NEW database and user (no conflicts)
- Sleep duration between hours: 1 hour (configurable in script)
- Total execution time: ~5 hours
- All INSERT operations are logged for audit trail
- Multi-row inserts count as 1 INSERT command but insert 3 rows

## Security Considerations
- User passwords are randomly generated with timestamp
- Each test is isolated in its own database
- No impact on existing databases or users
- All operations are auditable through MySQL logs
- Simulates realistic data injection patterns

## Use Cases
This test simulates:
1. **Data Injection Attack**: Malicious bulk data insertion
2. **Unauthorized Data Loading**: Insider loading sensitive data
3. **Database Flooding**: DoS attempt via excessive inserts
4. **Anomalous Batch Processing**: Unusual bulk data operations

---
**Made with Bob**
## Enable Demo Mode and Enable ATA in GDP

To enable demo mode and ATA (Advanced Threat Analytics) in GDP (Guardium Data Protection):

### Enable Demo Mode

1. **Access GDP Console**
   - Log in to your Guardium Data Protection console
   - Navigate to **Setup** > **Tools and Views** > **System Settings**

2. **Enable Demo Mode**
   - Go to **Demo Mode Settings**
   - Check the box for **Enable Demo Mode**
   - Click **Save**

### Enable ATA (Advanced Threat Analytics)

1. **Access ATA Settings**
   - Navigate to **Setup** > **Tools and Views** > **Advanced Threat Analytics**

2. **Enable ATA**
   - Check **Enable Advanced Threat Analytics**
   - Configure the following settings:
     - **Baseline Period**: Set appropriate baseline period (recommended: 7-14 days)
     - **Sensitivity Level**: Choose sensitivity level (Low/Medium/High)
     - **Alert Threshold**: Configure alert thresholds based on your requirements

3. **Configure ATA Policies**
   - Go to **Policy** > **ATA Policies**
   - Enable relevant policies for outlier detection:
     - Account Takeover Detection
     - Denial of Service Detection
     - Data Leak Detection
     - Schema Tampering Detection
     - Privilege Abuse Detection
     - Failed Login Detection

4. **Save Configuration**
   - Click **Save** to apply changes
   - ATA will start monitoring and learning baseline behavior

### Verification

After enabling demo mode and ATA:
- Run the outlier test scripts
- Monitor the GDP console for ATA alerts
- Check **Reports** > **ATA Reports** for detected anomalies
- Verify alerts are generated for the simulated attack patterns

### Notes

- Demo mode is useful for testing and demonstration purposes
- ATA requires a baseline period to establish normal behavior patterns
- Adjust sensitivity and thresholds based on your environment
- Review and tune ATA policies regularly for optimal detection



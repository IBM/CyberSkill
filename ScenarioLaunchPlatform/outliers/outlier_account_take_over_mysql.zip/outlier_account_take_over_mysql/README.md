# MySQL Account Takeover (ATO) Outlier Test

## Overview
This folder contains scripts to simulate an Account Takeover (ATO) attack pattern for MySQL outlier detection testing. The script automatically creates a unique database with 5 objects (tables) and a user for each run. It establishes a baseline by accessing only one object over time, then simulates account takeover by suddenly accessing all 5 objects.

## Purpose
- Test detection of Account Takeover attacks
- Simulate normal baseline: 4 hours of 50 SELECT queries on object1 (1 hour apart)
- Create anomaly spike: 1 hour of 50 SELECT queries on each of 5 objects (250 total)
- Generate realistic outlier patterns for security monitoring
- Test anomaly detection systems for ATO patterns
- Trigger ATA (Advanced Threat Analytics) Account Takeover case detection

## Attack Pattern

The test follows a specific time-based pattern designed to trigger ATO detection:

```
HOUR 1:  50 SELECTs on object1   → Sleep 1 hour
HOUR 2:  50 SELECTs on object1   → Sleep 1 hour
HOUR 3:  50 SELECTs on object1   → Sleep 1 hour
HOUR 4:  50 SELECTs on object1   → Sleep 1 hour
HOUR 5:  50 SELECTs on object1 + 50 on object2 + 50 on object3 + 50 on object4 + 50 on object5 (SPIKE - Account Takeover)
─────────────────────────────────────────────
TOTAL:  450 SELECT queries over ~5 hours
        200 baseline (object1 only)
        250 takeover (all 5 objects)
```

## Files

### 1. run_account_takeover_test.sh
Main script that executes the ATO attack pattern with time delays.

**What it does:**
- **Automatically generates unique database and user names** with timestamp (e.g., `atodb_20231230_120000`, `atouser_20231230_120000`)
- **Auto-creates database, 5 tables (objects), and user** if they don't exist
- Runs 4 baseline hours of 50 SELECT queries on object1 each
- Waits 1 hour between each run
- Runs 1 takeover hour with 50 SELECT queries on each of 5 objects (250 total)
- Uses **mysql_sql_executor_java** for hour 5 to execute via JDBC
- Logs all operations with timestamps
- Tracks execution time and progress
- Can run in foreground or background mode
- Generates detailed logs for each run

## Prerequisites
- MySQL Server 5.7 or higher
- MySQL client installed
- Java 1.8 or higher
- **Root access** (required for auto-creating database and user)
- Sufficient server resources to handle 205K+ queries
- Time: ~5 hours for full execution
- **Enable Demo Mode** - Ensure demo mode is enabled in your GDP system before running the test


## Usage

### Step 1 : Background Execution (Recommended for 5-hour run)
```bash
./run_account_takeover_test.sh <host> <port> <root_password> background
```

**Example:**
```bash
./run_account_takeover_test.sh localhost 3306 MyRootPass123 bg
# Or
./run_account_takeover_test.sh localhost 3306 MyRootPass123 background
```

**What happens automatically:**
- Creates unique database: `atodb_YYYYMMDD_HHMMSS`
- Creates unique user: `atouser_YYYYMMDD_HHMMSS`
- Creates 5 tables: `ato_object1`, `ato_object2`, `ato_object3`, `ato_object4`, `ato_object5`
- Inserts test data into each table
- Grants SELECT privileges
- Executes the ATO test pattern
- Uses Java executor for hour 5 (multi-object access)

### Monitor Background Execution
```bash
# View real-time logs
tail -f logs/account_takeover_background_*.log

# Check if still running
ps aux | grep run_account_takeover_test.sh

# Stop background execution
pkill -f run_account_takeover_test.sh
```

### Step 2: Cleanup (Optional - After Testing)
Each run creates a unique database and user, so cleanup is optional. If you want to remove them:

```bash
# Connect to MySQL and drop manually
mysql -h<host> -P<port> -uroot -p<root_password>

# List all ATO databases
SHOW DATABASES LIKE 'atodb_%';

# Drop specific database
DROP DATABASE atodb_20231230_120000;

# Drop specific user
DROP USER 'atouser_20231230_120000'@'%';
```

## Test Environment

### Database (Auto-Generated)
- **Database Name:** `atodb_YYYYMMDD_HHMMSS` (unique per run)
- **Created automatically** by run_account_takeover_test.sh

### Table Structure (5 Objects)
Each of the 5 tables has the same structure:

- **Table Names:** `ato_object1`, `ato_object2`, `ato_object3`, `ato_object4`, `ato_object5`
- **Columns:**
  - `id` (INT, AUTO_INCREMENT, PRIMARY KEY)
  - `data` (VARCHAR(255))
  - `created_at` (TIMESTAMP)
- **Sample Data:** 5 test records per table

### Test User (Auto-Generated)
- **Username:** `atouser_YYYYMMDD_HHMMSS` (unique per run)
- **Password:** `AtoPass123!`
- **Privileges:** SELECT on `atodb_YYYYMMDD_HHMMSS.*` (all tables)
- **Host:** `%` (can connect from anywhere)

## Query Pattern

### Hours 1-4 (Baseline - Normal Behavior)
All queries execute SELECT on object1 only:
```sql
SELECT * FROM ato_object1;
```
This query is repeated 50 times per hour for 4 hours (200 total).

### Hour 5 (Takeover - Anomaly)
Queries access all 5 objects via Java executor:
```sql
-- 50 times on each object
SELECT * FROM ato_object1;
SELECT * FROM ato_object2;
SELECT * FROM ato_object3;
SELECT * FROM ato_object4;
SELECT * FROM ato_object5;
```
Total: 250 SELECT queries (50 per object).

## Execution Timeline

```
Hour 0:  HOUR 1 - 50 SELECTs on object1 (baseline)
         ↓ Sleep 1 hour
Hour 1:  HOUR 2 - 50 SELECTs on object1 (baseline)
         ↓ Sleep 1 hour
Hour 2:  HOUR 3 - 50 SELECTs on object1 (baseline)
         ↓ Sleep 1 hour
Hour 3:  HOUR 4 - 50 SELECTs on object1 (baseline)
         ↓ Sleep 1 hour
Hour 4:  HOUR 5 - 50 SELECTs on each of 5 objects (SPIKE - Account Takeover)
         ↓ Complete
```

**Total Duration:** ~5 hours

## Run Breakdown

| Hour | Object1 | Object2 | Object3 | Object4 | Object5 | Total | Type | Purpose |
|------|---------|---------|---------|---------|---------|-------|------|---------|
| 1 | 50 | 0 | 0 | 0 | 0 | 50 | Baseline | Establish normal pattern |
| 2 | 50 | 0 | 0 | 0 | 0 | 50 | Baseline | Reinforce normal pattern |
| 3 | 50 | 0 | 0 | 0 | 0 | 50 | Baseline | Confirm normal pattern |
| 4 | 50 | 0 | 0 | 0 | 0 | 50 | Baseline | Final baseline |
| **5** | **50** | **50** | **50** | **50** | **50** | **250** | **SPIKE** | **Account Takeover** |
| **Total** | **250** | **50** | **50** | **50** | **50** | **450** | - | **Complete** |

## Expected Duration

- **Hour 1:** ~1-2 minutes + 1 hour sleep
- **Hour 2:** ~1-2 minutes + 1 hour sleep
- **Hour 3:** ~1-2 minutes + 1 hour sleep
- **Hour 4:** ~1-2 minutes + 1 hour sleep
- **Hour 5:** ~3-5 minutes (ATO spike via Java)
- **Total:** ~5 hours

## Logs

The script creates detailed logs in the `logs/` directory:

### Log Files
- `account_takeover_YYYYMMDD_HHMMSS.log` - Main execution log
- `account_takeover_background_YYYYMMDD_HHMMSS.log` - Background mode log
- `ato_run1_YYYYMMDD_HHMMSS.log` - Hour 1 detailed log
- `ato_run2_YYYYMMDD_HHMMSS.log` - Hour 2 detailed log
- `ato_run3_YYYYMMDD_HHMMSS.log` - Hour 3 detailed log
- `ato_run4_YYYYMMDD_HHMMSS.log` - Hour 4 detailed log
- `account_takeover_pid_YYYYMMDD_HHMMSS.txt` - Process ID file
- `hour5_selects.sql` - Generated SQL file for hour 5

### Log Contents
Each log includes:
- Timestamp for each operation
- Connection status
- Progress updates (every 10 queries)
- Query execution results
- Sleep notifications
- Success/failure status
- Total duration

## Verification

After execution, verify the test ran successfully:

```sql
-- Check if databases exist
SHOW DATABASES LIKE 'atodb_%';

-- Check if users exist
SELECT User, Host FROM mysql.user WHERE User LIKE 'atouser_%';

-- Check specific database (replace with your timestamp)
USE atodb_20231230_120000;
SHOW TABLES;

-- Check table data
SELECT * FROM ato_object1;
SELECT * FROM ato_object2;
SELECT * FROM ato_object3;
SELECT * FROM ato_object4;
SELECT * FROM ato_object5;

-- Check query logs (if general log is enabled)
-- This will show the pattern of queries
```

## Prerequisites

- MySQL Server 5.7 or higher
- MySQL client installed
- **Root access** (required for auto-creating database and user)
- **Java 8 or higher** (required for mysql_sql_executor_java)
- **mysql_sql_executor_java** compiled and ready (in ../mysql_sql_executor_java/)
- Sufficient server resources to handle 450+ queries
- Time: ~5 hours for full execution

## Monitoring and Detection

### What to Look For

After running this test, your monitoring systems should detect:

1. **Object Access Pattern Change**
   - Sudden increase from 1 object to 5 objects
   - Massive deviation from baseline access pattern

2. **Time-Based Pattern**
   - Consistent single-object access over 4 hours
   - Sudden multi-object access in hour 5

3. **User Behavior Anomaly**
   - Single user suddenly accessing multiple objects
   - Unusual access pattern indicating potential account compromise

4. **Query Volume Spike**
   - Increase from 50 to 250 queries per hour
   - 5x increase in query volume

5. **ATO Indicators**
   - Access to previously unaccessed objects
   - Sudden expansion of data access scope
   - Potential data exfiltration pattern

### ATA Case Detection

The pattern is specifically designed to trigger:
- **Account Takeover ATA Case**
- Baseline establishment (hours 1-4 accessing only object1)
- Anomaly spike detection (hour 5 accessing all 5 objects)
- User behavior analytics alert
- Object access pattern anomaly detection
- Time-based anomaly detection

## Troubleshooting

### Issue: Permission Denied
```bash
chmod +x run_account_takeover_test.sh
```

### Issue: MySQL Connection Failed
Check:
- Host and port are correct
- Root password is correct
- MySQL server is running
- User has appropriate privileges

### Issue: Java Executor Not Found
```bash
# Check if mysql_sql_executor_java exists
ls -la ../mysql_sql_executor_java/

# Compile if needed
cd ../mysql_sql_executor_java/
./compile.sh
cd ../outlier_account_take_over_mysql/
```

### Issue: Background Process Not Starting
```bash
# Check if nohup is available
which nohup

# Check logs directory permissions
ls -la logs/

# Verify script syntax
bash -n run_account_takeover_test.sh
```

### Issue: Script Stops Unexpectedly
```bash
# Check the logs
tail -100 logs/account_takeover_*.log

# Check for MySQL errors
tail -100 logs/ato_run*_*.log

# Verify MySQL is still running
mysql -h<host> -P<port> -uroot -p<password> -e "SELECT 1;"
```

### Issue: Hour 5 Java Execution Failed
```bash
# Check Java is installed
java -version

# Check MySQL connector exists
ls -la ../mysql_sql_executor_java/mysql-connector-*.jar

# Check db.properties was created
cat ../mysql_sql_executor_java/db.properties

# Test Java executor manually
cd ../mysql_sql_executor_java/
./run.sh ../outlier_account_take_over_mysql/hour5_selects.sql
```

### Issue: Auto-Setup Failed
```bash
# Verify root access
mysql -h<host> -P<port> -uroot -p<password> -e "SELECT 1;"

# Check if database was created
mysql -h<host> -P<port> -uroot -p<password> -e "SHOW DATABASES LIKE 'atodb_%';"

# Check logs for setup errors
tail -100 logs/account_takeover_*.log
```

## Security Notes

⚠️ **WARNING:** This script simulates an Account Takeover attack!

- Only run in test environments
- Never run on production databases
- May trigger security alerts (this is intentional)
- Ensure you have permission to run security tests
- Monitor server resources during execution
- Be prepared to stop the test if needed
- Test in isolated environment first

## Example Output

### Foreground Mode
```
============================================================================
Account Takeover Test - Starting
============================================================================
Configuration:
  Host: localhost
  Port: 3306
  Database: atodb_20231230_120000
  User: atouser_20231230_120000
  Pattern: 4 hours of 50 SELECTs on object1, then 1 hour of 50 SELECTs on each of 5 objects
  Sleep Between Runs: 1 hour(s)
  Log Directory: /path/to/logs
  Main Log: /path/to/logs/account_takeover_20231230_120000.log
============================================================================

Testing MySQL root connection...
✓ MySQL root connection successful

Setting up test environment...
  Database: atodb_20231230_120000
  User: atouser_20231230_120000
  Tables: ato_object1, ato_object2, ato_object3, ato_object4, ato_object5
✓ Environment setup completed successfully

========================================================================
HOUR 1 (1 of 5) - Baseline
========================================================================
RUN 1: Executing 50 SELECT queries on ato_object1...
  Progress: 10/50 queries executed on ato_object1...
  Progress: 20/50 queries executed on ato_object1...
  Progress: 30/50 queries executed on ato_object1...
  Progress: 40/50 queries executed on ato_object1...
  Progress: 50/50 queries executed on ato_object1...
  ✓ RUN 1: 50 queries on ato_object1 completed in 8 seconds

Sleeping for 1 hour(s) before next run...
Next run (HOUR 2) will start at: 2023-12-30 13:00:08

[... Hours 2-4 similar pattern ...]

========================================================================
HOUR 5 - ACCOUNT TAKEOVER SPIKE: Accessing all 5 objects via Java
========================================================================
Generating SQL file for hour 5: /path/to/hour5_selects.sql
✓ SQL file generated: /path/to/hour5_selects.sql
Creating db.properties for Java executor...
Executing 250 SELECT queries (50 per object) using Java executor...
✓ Hour 5: 250 queries (50 per object) completed in 45 seconds

============================================================================
Account Takeover Test Complete!
============================================================================
Total Runs: 5
Total Queries: 450 (200 baseline on object1 + 250 takeover on all 5 objects)
Total Duration: 4h 8m 15s
Logs Directory: /path/to/logs
Main Log: /path/to/logs/account_takeover_20231230_120000.log
============================================================================

Next outlier run should detect Account Takeover ATA case
============================================================================
```

## Integration with Monitoring

This script is designed to trigger alerts in:
- Database activity monitors
- Security information and event management (SIEM) systems
- Audit log analyzers
- Anomaly detection systems
- Advanced Threat Analytics (ATA) systems
- User Behavior Analytics (UBA) systems
- Account Takeover detection systems

Look for:
- Sudden expansion of object access (1 to 5 objects)
- Deviation from baseline access pattern
- Time-based anomaly (consistent baseline then spike)
- Single user accessing multiple previously unaccessed objects
- Query volume increase
- Potential data exfiltration pattern
- Account Takeover indicators

## Why This Pattern?

The pattern is specifically designed to:

1. **Establish Object Access Baseline** (Hours 1-4 over 4 hours)
   - 4 hours of accessing only object1
   - 1 hour apart to show consistent pattern
   - Creates normal behavior pattern over time
   - Allows anomaly detection to learn baseline

2. **Trigger ATO Detection** (Hour 5)
   - Sudden access to all 5 objects
   - 5x increase in object scope
   - Clear anomaly spike
   - Triggers ATA Account Takeover case

This pattern mimics real-world Account Takeover attacks where:
- Attacker gains access to legitimate account
- Initially accesses familiar resources (object1)
- Then expands access to exfiltrate more data (all 5 objects)
- Creates clear before/after pattern
- Time-based anomaly is more realistic
- Uses different access method (Java/JDBC) to simulate tool change

## Made with Bob
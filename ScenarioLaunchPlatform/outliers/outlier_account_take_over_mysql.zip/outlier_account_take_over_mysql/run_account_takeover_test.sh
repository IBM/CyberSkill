#!/bin/bash
# ============================================================================
# Script: run_account_takeover_test.sh
# Purpose: Simulate Account Takeover pattern with object access anomaly
# Pattern: 4 hours of 50 SELECTs on object1, then 1 hour of 50 SELECTs on each of 5 objects
# Usage: ./run_account_takeover_test.sh <host> <port> <root_password> [background|bg]
# ============================================================================

if [ "$#" -lt 3 ] || [ "$#" -gt 4 ]; then
    echo "Usage: $0 <host> <port> <root_password> [background|bg]"
    echo "Example: $0 localhost 3306 MyRootPass123"
    echo "Example (background): $0 localhost 3306 MyRootPass123 background"
    exit 1
fi

DB_HOST="$1"
DB_PORT="$2"
ROOT_PASSWORD="$3"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_DIR="$SCRIPT_DIR/logs"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
MAIN_LOG="$LOG_DIR/account_takeover_${TIMESTAMP}.log"
BACKGROUND_LOG="$LOG_DIR/account_takeover_background_${TIMESTAMP}.log"

# Configuration
SLEEP_HOURS=1
SLEEP_SECONDS=$((SLEEP_HOURS * 3600))

# Generate unique database and user names with timestamp
DB_NAME="atodb_${TIMESTAMP}"
DB_USER="atouser_${TIMESTAMP}"
USER_PASSWORD="AtoPass123!"

# Create logs directory
mkdir -p "$LOG_DIR"

# Function to log messages
log_message() {
    local message="$1"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $message" | tee -a "$MAIN_LOG"
}

# Function to setup database, tables, and user
setup_environment() {
    log_message "Setting up test environment..."
    log_message "  Database: $DB_NAME"
    log_message "  User: $DB_USER"
    log_message "  Tables: ato_object1, ato_object2, ato_object3, ato_object4, ato_object5"
    
    mysql -h"$DB_HOST" -P"$DB_PORT" -uroot -p"$ROOT_PASSWORD" <<EOF >> "$MAIN_LOG" 2>&1
-- Create database
CREATE DATABASE IF NOT EXISTS $DB_NAME;
USE $DB_NAME;

-- Create 5 test tables (objects)
CREATE TABLE IF NOT EXISTS ato_object1 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    data VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS ato_object2 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    data VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS ato_object3 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    data VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS ato_object4 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    data VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS ato_object5 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    data VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert test data into each table
INSERT INTO ato_object1 (data) VALUES
('Object1 Data 1'), ('Object1 Data 2'), ('Object1 Data 3'), ('Object1 Data 4'), ('Object1 Data 5');

INSERT INTO ato_object2 (data) VALUES
('Object2 Data 1'), ('Object2 Data 2'), ('Object2 Data 3'), ('Object2 Data 4'), ('Object2 Data 5');

INSERT INTO ato_object3 (data) VALUES
('Object3 Data 1'), ('Object3 Data 2'), ('Object3 Data 3'), ('Object3 Data 4'), ('Object3 Data 5');

INSERT INTO ato_object4 (data) VALUES
('Object4 Data 1'), ('Object4 Data 2'), ('Object4 Data 3'), ('Object4 Data 4'), ('Object4 Data 5');

INSERT INTO ato_object5 (data) VALUES
('Object5 Data 1'), ('Object5 Data 2'), ('Object5 Data 3'), ('Object5 Data 4'), ('Object5 Data 5');

-- Create test user
DROP USER IF EXISTS '$DB_USER'@'%';
CREATE USER '$DB_USER'@'%' IDENTIFIED BY '$USER_PASSWORD';

-- Grant SELECT privilege on all tables
GRANT SELECT ON $DB_NAME.* TO '$DB_USER'@'%';
FLUSH PRIVILEGES;
EOF
    
    if [ $? -eq 0 ]; then
        log_message "✓ Environment setup completed successfully"
        return 0
    else
        log_message "✗ Environment setup failed!"
        return 1
    fi
}

# Function to execute SELECT queries on a specific table
execute_selects() {
    local num_queries="$1"
    local table_name="$2"
    local run_num="$3"
    local run_log="$LOG_DIR/ato_run${run_num}_${TIMESTAMP}.log"
    
    log_message "RUN ${run_num}: Executing ${num_queries} SELECT queries on ${table_name}..."
    
    local start_time=$(date +%s)
    local failed_queries=0
    
    for i in $(seq 1 $num_queries); do
        mysql -h"$DB_HOST" -P"$DB_PORT" -u"$DB_USER" -p"$USER_PASSWORD" "$DB_NAME" -e "SELECT * FROM ${table_name};" >> "$run_log" 2>&1
        local mysql_exit=$?
        
        if [ $mysql_exit -ne 0 ]; then
            log_message "  ✗ Query $i failed (exit code: $mysql_exit)"
            ((failed_queries++))
            # Continue to try remaining queries but track failures
        fi
        
        # Show progress every 10 queries
        if [ $((i % 10)) -eq 0 ]; then
            log_message "  Progress: ${i}/${num_queries} queries executed on ${table_name}..."
        fi
    done
    
    local end_time=$(date +%s)
    local duration=$((end_time - start_time))
    local successful_queries=$((num_queries - failed_queries))
    
    if [ $failed_queries -eq 0 ]; then
        log_message "  ✓ RUN ${run_num}: ${num_queries} queries on ${table_name} completed successfully in ${duration} seconds"
        return 0
    else
        log_message "  ⚠ RUN ${run_num}: ${successful_queries}/${num_queries} queries succeeded, ${failed_queries} failed in ${duration} seconds (check $run_log)"
        return 1
    fi
}

# Function to generate SQL file for hour 5 (Java executor)
generate_hour5_sql() {
    local sql_file="$SCRIPT_DIR/hour5_selects.sql"
    log_message "Generating SQL file for hour 5: $sql_file"
    
    cat > "$sql_file" <<EOF
-- Hour 5: Account Takeover - Access to all 5 objects
-- 100 SELECT queries on each of 5 objects (500 total)
USE $DB_NAME;

EOF
    
    # Generate 100 SELECTs for each of the 5 objects
    for obj_num in {1..5}; do
        echo "-- 100 SELECTs on ato_object${obj_num}" >> "$sql_file"
        for i in {1..100}; do
            echo "SELECT * FROM ato_object${obj_num};" >> "$sql_file"
        done
        echo "" >> "$sql_file"
    done
    
    log_message "✓ SQL file generated: $sql_file (500 queries total)"
}

# Function to execute hour 5 using Java executor
execute_hour5_java() {
    local sql_file="$SCRIPT_DIR/hour5_selects.sql"
    local java_dir="$SCRIPT_DIR/mysql_sql_executor_java"
    local db_props="$java_dir/db.properties"
    
    log_message "========================================================================"
    log_message "HOUR 5 - ACCOUNT TAKEOVER SPIKE: Accessing all 5 objects via Java"
    log_message "========================================================================"
    
    # Create db.properties for Java executor
    log_message "Creating db.properties for Java executor..."
    cat > "$db_props" <<EOF
db.host=$DB_HOST
db.port=$DB_PORT
db.database=$DB_NAME
db.username=$DB_USER
db.password=$USER_PASSWORD
EOF
    
    log_message "Executing 500 SELECT queries (100 per object) using Java executor..."
    local start_time=$(date +%s)
    
    cd "$java_dir"
    ./run.sh "$sql_file" >> "$MAIN_LOG" 2>&1
    local exit_code=$?
    cd "$SCRIPT_DIR"
    
    local end_time=$(date +%s)
    local duration=$((end_time - start_time))
    
    if [ $exit_code -eq 0 ]; then
        log_message "✓ Hour 5: 500 queries (100 per object) completed in ${duration} seconds"
        return 0
    else
        log_message "✗ Hour 5: Java execution failed (check logs)"
        return 1
    fi
}

# Main execution function
main_execution() {
    log_message "============================================================================"
    log_message "Account Takeover Test - Starting"
    log_message "============================================================================"
    log_message "Configuration:"
    log_message "  Host: $DB_HOST"
    log_message "  Port: $DB_PORT"
    log_message "  Database: $DB_NAME"
    log_message "  User: $DB_USER"
    log_message "  Pattern: 4 hours of 50 SELECTs on object1, then 1 hour of 50 SELECTs on each of 5 objects"
    log_message "  Sleep Between Runs: $SLEEP_HOURS hour(s)"
    log_message "  Log Directory: $LOG_DIR"
    log_message "  Main Log: $MAIN_LOG"
    log_message "============================================================================"
    log_message ""

    # Test MySQL root connection
    log_message "Testing MySQL root connection..."
    if mysql -h"$DB_HOST" -P"$DB_PORT" -uroot -p"$ROOT_PASSWORD" -e "SELECT 'Connection successful' AS Status;" > /dev/null 2>&1; then
        log_message "✓ MySQL root connection successful"
    else
        log_message "✗ MySQL root connection failed!"
        log_message "Please check host, port, and root password."
        exit 1
    fi
    log_message ""

    # Setup environment (database, tables, user)
    setup_environment
    if [ $? -ne 0 ]; then
        log_message "✗ Failed to setup environment. Exiting."
        exit 1
    fi
    log_message ""

    # Start time
    local TEST_START=$(date +%s)

    # HOUR 1: 50 SELECTs on object1
    log_message "========================================================================"
    log_message "HOUR 1 (1 of 5) - Baseline"
    log_message "========================================================================"
    execute_selects 50 "ato_object1" 1
    log_message ""
    log_message "Sleeping for $SLEEP_HOURS hour(s) before next run..."
    log_message "Next run (HOUR 2) will start at: $(date -d "+${SLEEP_HOURS} hours" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date -v+${SLEEP_HOURS}H '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo 'N/A')"
    log_message ""
    sleep $SLEEP_SECONDS

    # HOUR 2: 50 SELECTs on object1
    log_message "========================================================================"
    log_message "HOUR 2 (2 of 5) - Baseline"
    log_message "========================================================================"
    execute_selects 50 "ato_object1" 2
    log_message ""
    log_message "Sleeping for $SLEEP_HOURS hour(s) before next run..."
    log_message "Next run (HOUR 3) will start at: $(date -d "+${SLEEP_HOURS} hours" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date -v+${SLEEP_HOURS}H '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo 'N/A')"
    log_message ""
    sleep $SLEEP_SECONDS

    # HOUR 3: 50 SELECTs on object1
    log_message "========================================================================"
    log_message "HOUR 3 (3 of 5) - Baseline"
    log_message "========================================================================"
    execute_selects 50 "ato_object1" 3
    log_message ""
    log_message "Sleeping for $SLEEP_HOURS hour(s) before next run..."
    log_message "Next run (HOUR 4) will start at: $(date -d "+${SLEEP_HOURS} hours" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date -v+${SLEEP_HOURS}H '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo 'N/A')"
    log_message ""
    sleep $SLEEP_SECONDS

    # HOUR 4: 50 SELECTs on object1
    log_message "========================================================================"
    log_message "HOUR 4 (4 of 5) - Baseline"
    log_message "========================================================================"
    execute_selects 50 "ato_object1" 4
    log_message ""
    log_message "Sleeping for $SLEEP_HOURS hour(s) before TAKEOVER run..."
    log_message "TAKEOVER run (HOUR 5 - accessing all 5 objects) will start at: $(date -d "+${SLEEP_HOURS} hours" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date -v+${SLEEP_HOURS}H '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo 'N/A')"
    log_message ""
    sleep $SLEEP_SECONDS

    # HOUR 5: Generate SQL and execute via Java (50 SELECTs on each of 5 objects)
    generate_hour5_sql
    execute_hour5_java
    log_message ""

    # End time and summary
    local TEST_END=$(date +%s)
    local TOTAL_DURATION=$((TEST_END - TEST_START))
    local HOURS=$((TOTAL_DURATION / 3600))
    local MINUTES=$(((TOTAL_DURATION % 3600) / 60))
    local SECONDS=$((TOTAL_DURATION % 60))

    log_message "============================================================================"
    log_message "Account Takeover Test Complete!"
    log_message "============================================================================"
    log_message "Total Runs: 5"
    log_message "Total Queries: 700 (200 baseline on object1 + 500 takeover on all 5 objects)"
    log_message "Total Duration: ${HOURS}h ${MINUTES}m ${SECONDS}s"
    log_message "Logs Directory: $LOG_DIR"
    log_message "Main Log: $MAIN_LOG"
    log_message "============================================================================"
    log_message ""
    log_message "Next outlier run should detect Account Takeover ATA case"
    log_message "============================================================================"
}

# Check if we should run in background
if [ "$4" = "background" ] || [ "$4" = "bg" ]; then
    # Run in background with nohup
    echo "============================================================================"
    echo "Starting Account Takeover Test in Background"
    echo "============================================================================"
    echo "Host: $DB_HOST"
    echo "Port: $DB_PORT"
    echo "Background Log: $BACKGROUND_LOG"
    echo "============================================================================"
    echo ""
    echo "The script is now running in the background."
    echo "To monitor progress:"
    echo "  tail -f $BACKGROUND_LOG"
    echo ""
    echo "To check if it's still running:"
    echo "  ps aux | grep run_account_takeover_test.sh"
    echo ""
    echo "To stop it:"
    echo "  pkill -f run_account_takeover_test.sh"
    echo "============================================================================"
    
    # Export all variables for background execution
    export DB_HOST DB_PORT ROOT_PASSWORD DB_NAME DB_USER USER_PASSWORD SCRIPT_DIR SLEEP_HOURS SLEEP_SECONDS LOG_DIR TIMESTAMP MAIN_LOG
    
    nohup bash -c '
        # Re-import variables
        DB_HOST="'"$DB_HOST"'"
        DB_PORT="'"$DB_PORT"'"
        ROOT_PASSWORD="'"$ROOT_PASSWORD"'"
        DB_NAME="'"$DB_NAME"'"
        DB_USER="'"$DB_USER"'"
        USER_PASSWORD="'"$USER_PASSWORD"'"
        SCRIPT_DIR="'"$SCRIPT_DIR"'"
        SLEEP_HOURS='"$SLEEP_HOURS"'
        SLEEP_SECONDS='"$SLEEP_SECONDS"'
        LOG_DIR="'"$LOG_DIR"'"
        TIMESTAMP="'"$TIMESTAMP"'"
        MAIN_LOG="'"$LOG_DIR"'/account_takeover_'"$TIMESTAMP"'.log"
        
        # Define functions
        '"$(declare -f log_message)"'
        '"$(declare -f setup_environment)"'
        '"$(declare -f execute_selects)"'
        '"$(declare -f generate_hour5_sql)"'
        '"$(declare -f execute_hour5_java)"'
        '"$(declare -f main_execution)"'
        
        # Run main execution
        main_execution
    ' > "$BACKGROUND_LOG" 2>&1 &
    
    BG_PID=$!
    echo "Background Process ID: $BG_PID"
    echo "$BG_PID" > "$LOG_DIR/account_takeover_pid_${TIMESTAMP}.txt"
    echo ""
    echo "Script launched successfully!"
    echo "PID saved to: $LOG_DIR/account_takeover_pid_${TIMESTAMP}.txt"
else
    # Run in foreground
    main_execution
fi

# Made with Bob
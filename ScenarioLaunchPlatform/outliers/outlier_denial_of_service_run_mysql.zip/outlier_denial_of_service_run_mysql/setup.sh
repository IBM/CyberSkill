#!/bin/bash
# ============================================================================
# Script: setup.sh
# Purpose: Setup database, table, and user for Denial of Service test
# Usage: ./setup.sh <host> <port> <root_password>
# ============================================================================

if [ "$#" -ne 3 ]; then
    echo "Usage: $0 <host> <port> <root_password>"
    echo "Example: $0 localhost 3306 MyPassword123"
    exit 1
fi

DB_HOST="$1"
DB_PORT="$2"
ROOT_PASSWORD="$3"

echo "============================================================================"
echo "Setting up Denial of Service Test Environment"
echo "============================================================================"
echo "Host: $DB_HOST"
echo "Port: $DB_PORT"
echo "============================================================================"
echo ""

# Create database, table, and user
mysql -h"$DB_HOST" -P"$DB_PORT" -uroot -p"$ROOT_PASSWORD" <<EOF
-- Create database
CREATE DATABASE IF NOT EXISTS testdb;
USE testdb;

-- Create test table
CREATE TABLE IF NOT EXISTS dos_test_table (
    id INT AUTO_INCREMENT PRIMARY KEY,
    data VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert some test data
INSERT INTO dos_test_table (data) VALUES
('Test data 1'),
('Test data 2'),
('Test data 3'),
('Test data 4'),
('Test data 5');

-- Create test user
DROP USER IF EXISTS 'dosuser'@'%';
CREATE USER 'dosuser'@'%' IDENTIFIED BY 'DosPass123!';

-- Grant SELECT privilege on the table
GRANT SELECT ON testdb.dos_test_table TO 'dosuser'@'%';
FLUSH PRIVILEGES;

-- Verify setup
SELECT 'Database and table created' AS Status;
SELECT COUNT(*) AS RecordCount FROM dos_test_table;
SELECT User, Host FROM mysql.user WHERE User = 'dosuser';
EOF

if [ $? -eq 0 ]; then
    echo ""
    echo "============================================================================"
    echo "Setup Complete!"
    echo "============================================================================"
    echo "Database: testdb"
    echo "Table: dos_test_table"
    echo "User: dosuser"
    echo "Password: DosPass123!"
    echo "============================================================================"
else
    echo ""
    echo "Setup failed! Please check the error messages above."
    exit 1
fi

# Made with Bob

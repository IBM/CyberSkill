#!/bin/bash
# ============================================================================
# Script: cleanup.sh
# Purpose: Cleanup database, table, and user created for DoS test
# Usage: ./cleanup.sh <host> <port> <root_password>
# ============================================================================

if [ "$#" -ne 3 ]; then
    echo "Usage: $0 <host> <port> <root_password>"
    echo "Example: $0 localhost 3306 MyPassword123"
    exit 1
fi

DB_HOST="$1"
DB_PORT="$2"
ROOT_PASSWORD="$3"

echo "============================================================================"
echo "Cleaning up Denial of Service Test Environment"
echo "============================================================================"
echo "Host: $DB_HOST"
echo "Port: $DB_PORT"
echo "============================================================================"
echo ""

# Cleanup database and user
mysql -h"$DB_HOST" -P"$DB_PORT" -uroot -p"$ROOT_PASSWORD" <<EOF
-- Drop user
DROP USER IF EXISTS 'dosuser'@'%';

-- Drop table
DROP TABLE IF EXISTS testdb.dos_test_table;

-- Optionally drop database (uncomment if needed)
-- DROP DATABASE IF EXISTS testdb;

SELECT 'Cleanup complete' AS Status;
EOF

if [ $? -eq 0 ]; then
    echo ""
    echo "============================================================================"
    echo "Cleanup Complete!"
    echo "============================================================================"
    echo "User 'dosuser' removed"
    echo "Table 'dos_test_table' removed"
    echo "============================================================================"
else
    echo ""
    echo "Cleanup failed! Please check the error messages above."
    exit 1
fi

# Made with Bob

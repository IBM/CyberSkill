#!/bin/bash
# ============================================================================
# Script: run_dos_test.sh
# Purpose: Execute Denial of Service test pattern with 1-hour sleep between runs
# Pattern: 4 runs of 1001 queries (1 hour apart), then 1 run of 205000 queries
# Usage: ./run_dos_test.sh <host> <port> <root_password> [background|bg]
# ============================================================================

if [ "$#" -lt 3 ] || [ "$#" -gt 4 ]; then
    echo "Usage: $0 <host> <port> <root_password> [background|bg]"
    echo "Example: $0 localhost 3306 MyRootPass123"
    echo "Example (background): $0 localhost 3306 MyRootPass123 background"
    exit 1
fi

DB_HOST="$1"
DB_PORT="$2"
ROOT_PASSWORD="$3"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_DIR="$SCRIPT_DIR/logs"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
MAIN_LOG="$LOG_DIR/dos_test_${TIMESTAMP}.log"
BACKGROUND_LOG="$LOG_DIR/dos_test_background_${TIMESTAMP}.log"

# Generate unique database and user names with timestamp
DB_NAME="dosdb_${TIMESTAMP}"
DB_USER="dosuser_${TIMESTAMP}"
USER_PASSWORD="DosPass123!"
TABLE_NAME="dos_test_table"

# Configuration
SLEEP_HOURS=1
SLEEP_SECONDS=$((SLEEP_HOURS * 3600))

# Create logs directory
mkdir -p "$LOG_DIR"

# Function to log messages
log_message() {
    local message="$1"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $message" | tee -a "$MAIN_LOG"
}

# Function to execute queries
# Function to setup database, table, and user
setup_environment() {
    log_message "Setting up test environment..."
    log_message "  Database: $DB_NAME"
    log_message "  User: $DB_USER"
    log_message "  Table: $TABLE_NAME"
    
    mysql -h"$DB_HOST" -P"$DB_PORT" -uroot -p"$ROOT_PASSWORD" <<EOF >> "$MAIN_LOG" 2>&1
-- Create database
CREATE DATABASE IF NOT EXISTS $DB_NAME;
USE $DB_NAME;

-- Create test table
CREATE TABLE IF NOT EXISTS $TABLE_NAME (
    id INT AUTO_INCREMENT PRIMARY KEY,
    data VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert some test data
INSERT INTO $TABLE_NAME (data) VALUES
('Test data 1'),
('Test data 2'),
('Test data 3'),
('Test data 4'),
('Test data 5');

-- Create test user
DROP USER IF EXISTS '$DB_USER'@'%';
CREATE USER '$DB_USER'@'%' IDENTIFIED BY '$USER_PASSWORD';

-- Grant SELECT privilege on the table
GRANT SELECT ON $DB_NAME.$TABLE_NAME TO '$DB_USER'@'%';
FLUSH PRIVILEGES;
EOF
    
    if [ $? -eq 0 ]; then
        log_message "✓ Environment setup completed successfully"
        return 0
    else
        log_message "✗ Environment setup failed!"
        return 1
    fi
}

# Function to execute queries
execute_queries() {
    local num_queries="$1"
    local run_num="$2"
    local run_log="$LOG_DIR/dos_run${run_num}_${TIMESTAMP}.log"
    
    log_message "RUN ${run_num}: Executing ${num_queries} SELECT queries..."
    
    local start_time=$(date +%s)
    
    for i in $(seq 1 $num_queries); do
        mysql -h"$DB_HOST" -P"$DB_PORT" -u"$DB_USER" -p"$USER_PASSWORD" "$DB_NAME" -e "SELECT * FROM $TABLE_NAME;" >> "$run_log" 2>&1
        
        # Show progress every 1000 queries
        if [ $((i % 1000)) -eq 0 ]; then
            log_message "  Progress: ${i}/${num_queries} queries executed..."
        fi
    done
    
    local end_time=$(date +%s)
    local duration=$((end_time - start_time))
    
    if [ $? -eq 0 ]; then
        log_message "  ✓ RUN ${run_num}: ${num_queries} queries completed in ${duration} seconds"
        return 0
    else
        log_message "  ✗ RUN ${run_num}: Query execution failed (check $run_log)"
        return 1
    fi
}

# Main execution function
main_execution() {
    log_message "============================================================================"
    log_message "Denial of Service Test - Starting"
    log_message "============================================================================"
    log_message "Configuration:"
    log_message "  Host: $DB_HOST"
    log_message "  Port: $DB_PORT"
    log_message "  Database: $DB_NAME"
    log_message "  User: $DB_USER"
    log_message "  Table: $TABLE_NAME"
    log_message "  Pattern: 4 runs of 1001 queries (1 hour apart), then 1 run of 205000 queries"
    log_message "  Sleep Between Runs: $SLEEP_HOURS hour(s)"
    log_message "  Log Directory: $LOG_DIR"
    log_message "  Main Log: $MAIN_LOG"
    log_message "============================================================================"
    log_message ""

    # Test MySQL root connection
    log_message "Testing MySQL root connection..."
    if mysql -h"$DB_HOST" -P"$DB_PORT" -uroot -p"$ROOT_PASSWORD" -e "SELECT 'Connection successful' AS Status;" > /dev/null 2>&1; then
        log_message "✓ MySQL root connection successful"
    else
        log_message "✗ MySQL root connection failed!"
        log_message "Please check host, port, and root password."
        exit 1
    fi
    log_message ""

    # Setup environment (database, table, user)
    setup_environment
    if [ $? -ne 0 ]; then
        log_message "✗ Failed to setup environment. Exiting."
        exit 1
    fi
    log_message ""

    # Start time
    local TEST_START=$(date +%s)

    # FIRST RUN: 1001 queries
    log_message "========================================================================"
    log_message "FIRST RUN (1 of 5)"
    log_message "========================================================================"
    execute_queries 1001 1
    log_message ""
    log_message "Sleeping for $SLEEP_HOURS hour(s) before next run..."
    log_message "Next run (RUN 2) will start at: $(date -d "+${SLEEP_HOURS} hours" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date -v+${SLEEP_HOURS}H '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo 'N/A')"
    log_message ""
    sleep $SLEEP_SECONDS

    # SECOND RUN: 1001 queries
    log_message "========================================================================"
    log_message "SECOND RUN (2 of 5)"
    log_message "========================================================================"
    execute_queries 1001 2
    log_message ""
    log_message "Sleeping for $SLEEP_HOURS hour(s) before next run..."
    log_message "Next run (RUN 3) will start at: $(date -d "+${SLEEP_HOURS} hours" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date -v+${SLEEP_HOURS}H '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo 'N/A')"
    log_message ""
    sleep $SLEEP_SECONDS

    # THIRD RUN: 1001 queries
    log_message "========================================================================"
    log_message "THIRD RUN (3 of 5)"
    log_message "========================================================================"
    execute_queries 1001 3
    log_message ""
    log_message "Sleeping for $SLEEP_HOURS hour(s) before next run..."
    log_message "Next run (RUN 4) will start at: $(date -d "+${SLEEP_HOURS} hours" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date -v+${SLEEP_HOURS}H '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo 'N/A')"
    log_message ""
    sleep $SLEEP_SECONDS

    # FOURTH RUN: 1001 queries
    log_message "========================================================================"
    log_message "FOURTH RUN (4 of 5)"
    log_message "========================================================================"
    execute_queries 1001 4
    log_message ""
    log_message "Sleeping for $SLEEP_HOURS hour(s) before SPIKE run..."
    log_message "SPIKE run (RUN 5 - 205000 queries) will start at: $(date -d "+${SLEEP_HOURS} hours" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date -v+${SLEEP_HOURS}H '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo 'N/A')"
    log_message ""
    sleep $SLEEP_SECONDS

    # FIFTH RUN: 205000 queries (SPIKE - Denial of Service)
    log_message "========================================================================"
    log_message "FIFTH RUN (5 of 5) - DENIAL OF SERVICE SPIKE: 205000 QUERIES"
    log_message "========================================================================"
    execute_queries 205000 5
    log_message ""

    # End time and summary
    local TEST_END=$(date +%s)
    local TOTAL_DURATION=$((TEST_END - TEST_START))
    local HOURS=$((TOTAL_DURATION / 3600))
    local MINUTES=$(((TOTAL_DURATION % 3600) / 60))
    local SECONDS=$((TOTAL_DURATION % 60))

    log_message "============================================================================"
    log_message "Denial of Service Test Complete!"
    log_message "============================================================================"
    log_message "Total Runs: 5"
    log_message "Total Queries: 209004 (4004 normal + 205000 spike)"
    log_message "Total Duration: ${HOURS}h ${MINUTES}m ${SECONDS}s"
    log_message "Logs Directory: $LOG_DIR"
    log_message "Main Log: $MAIN_LOG"
    log_message "============================================================================"
    log_message ""
    log_message "Next outlier run should detect Denial of Service ATA case"
    log_message "============================================================================"
}

# Check if we should run in background
if [ "$4" = "background" ] || [ "$4" = "bg" ]; then
    # Run in background with nohup
    echo "============================================================================"
    echo "Starting Denial of Service Test in Background"
    echo "============================================================================"
    echo "Host: $DB_HOST"
    echo "Port: $DB_PORT"
    echo "Background Log: $BACKGROUND_LOG"
    echo "============================================================================"
    echo ""
    echo "The script is now running in the background."
    echo "To monitor progress:"
    echo "  tail -f $BACKGROUND_LOG"
    echo ""
    echo "To check if it's still running:"
    echo "  ps aux | grep run_dos_test.sh"
    echo ""
    echo "To stop it:"
    echo "  pkill -f run_dos_test.sh"
    echo "============================================================================"
    
    # Export all variables for background execution
    export DB_HOST DB_PORT ROOT_PASSWORD DB_NAME DB_USER USER_PASSWORD TABLE_NAME SCRIPT_DIR SLEEP_HOURS SLEEP_SECONDS LOG_DIR TIMESTAMP MAIN_LOG
    
    nohup bash -c '
        # Re-import variables
        DB_HOST="'"$DB_HOST"'"
        DB_PORT="'"$DB_PORT"'"
        ROOT_PASSWORD="'"$ROOT_PASSWORD"'"
        DB_NAME="'"$DB_NAME"'"
        DB_USER="'"$DB_USER"'"
        USER_PASSWORD="'"$USER_PASSWORD"'"
        TABLE_NAME="'"$TABLE_NAME"'"
        SCRIPT_DIR="'"$SCRIPT_DIR"'"
        SLEEP_HOURS='"$SLEEP_HOURS"'
        SLEEP_SECONDS='"$SLEEP_SECONDS"'
        LOG_DIR="'"$LOG_DIR"'"
        TIMESTAMP="'"$TIMESTAMP"'"
        MAIN_LOG="'"$LOG_DIR"'/dos_test_'"$TIMESTAMP"'.log"
        
        # Define functions
        '"$(declare -f log_message)"'
        '"$(declare -f setup_environment)"'
        '"$(declare -f execute_queries)"'
        '"$(declare -f main_execution)"'
        
        # Run main execution
        main_execution
    ' > "$BACKGROUND_LOG" 2>&1 &
    
    BG_PID=$!
    echo "Background Process ID: $BG_PID"
    echo "$BG_PID" > "$LOG_DIR/dos_test_pid_${TIMESTAMP}.txt"
    echo ""
    echo "Script launched successfully!"
    echo "PID saved to: $LOG_DIR/dos_test_pid_${TIMESTAMP}.txt"
else
    # Run in foreground
    main_execution
fi

# Made with Bob

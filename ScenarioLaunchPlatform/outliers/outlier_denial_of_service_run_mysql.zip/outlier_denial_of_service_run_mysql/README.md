# MySQL Denial of Service (DoS) Outlier Test

## Overview
This folder contains scripts to simulate a Denial of Service (DoS) attack pattern for MySQL outlier detection testing. The script automatically creates a unique database and user for each run, establishes a baseline with normal query volumes over time, then executes a massive spike to trigger DoS detection.

## Purpose
- Test detection of Denial of Service attacks
- Simulate normal baseline: 4 runs of 1001 queries each (1 hour apart)
- Create anomaly spike: 1 run of 205000 queries (DoS attack)
- Generate realistic outlier patterns for security monitoring
- Test anomaly detection systems for DoS patterns
- Trigger ATA (Advanced Threat Analytics) DoS case detection

## Attack Pattern

The test follows a specific time-based pattern designed to trigger DoS detection:

```
RUN 1:  1,001 queries   → Sleep 1 hour
RUN 2:  1,001 queries   → Sleep 1 hour
RUN 3:  1,001 queries   → Sleep 1 hour
RUN 4:  1,001 queries   → Sleep 1 hour
RUN 5:  205,000 queries (SPIKE - DoS Attack)
─────────────────────────────────────────────
TOTAL:  209,004 queries over ~5 hours
```

## Files

### 1. run_dos_test.sh
Main script that executes the DoS attack pattern with time delays.

**What it does:**
- **Automatically generates unique database and user names** with timestamp (e.g., `dosdb_20231230_120000`, `dosuser_20231230_120000`)
- **Auto-creates database, table, and user** if they don't exist
- Runs 4 baseline batches of 1001 queries each
- Waits 1 hour between each run
- Runs 1 spike batch of 205000 queries
- Logs all operations with timestamps
- Tracks execution time and progress
- Can run in foreground or background mode
- Generates detailed logs for each run

### 2. setup.sh (Optional - Legacy)
Legacy setup script. **No longer required** as run_dos_test.sh now handles setup automatically.

### 3. cleanup.sh
Removes the test environment (if needed for manual cleanup).

## Prerequisites

- MySQL Server 5.7 or higher
- MySQL client installed
- **Root access** (required for auto-creating database and user)
- Sufficient server resources to handle 205K+ queries
- Time: ~5 hours for full execution
- **Enable Demo Mode** - Ensure demo mode is enabled in your GDP system before running the test
- **GDP Working Hours** - Run the script during GDP working hours: **8:00 AM to 6:00 PM** or GDP non-working hours: 6:00 PM to 8:00 AM
- Run the script at the starting hours, like 8:01 AM to 8:10 AM, 9:01 AM to 9:10 AM, etc.
## Usage

### Quick Start (Recommended)

The script now **automatically creates unique database and user** for each run. No manual setup required!


### Step 1: Background Execution 
```bash
./run_dos_test.sh <host> <port> <root_password> background
```

**Example:**
```bash
./run_dos_test.sh localhost 3306 MyRootPass123 bg
# Or
./run_dos_test.sh localhost 3306 MyRootPass123 background
```

**What happens automatically:**
- Creates unique database: `dosdb_YYYYMMDD_HHMMSS`
- Creates unique user: `dosuser_YYYYMMDD_HHMMSS`
- Creates table: `dos_test_table`
- Inserts test data
- Grants SELECT privileges
- Executes the DoS test pattern

### Monitor Background Execution
```bash
# View real-time logs
tail -f logs/dos_test_background_*.log

# Check if still running
ps aux | grep run_dos_test.sh

# Stop background execution
pkill -f run_dos_test.sh
```

### Step 2: Cleanup (Optional - After Testing)
Each run creates a unique database and user, so cleanup is optional. If you want to remove them:

```bash
# Connect to MySQL and drop manually
mysql -h<host> -P<port> -uroot -p<root_password>

# List all DoS databases
SHOW DATABASES LIKE 'dosdb_%';

# Drop specific database
DROP DATABASE dosdb_20231230_120000;

# Drop specific user
DROP USER 'dosuser_20231230_120000'@'%';
```

## Test Environment

### Database (Auto-Generated)
- **Database Name:** `dosdb_YYYYMMDD_HHMMSS` (unique per run)
- **Created automatically** by run_dos_test.sh

### Table Structure
- **Table Name:** `dos_test_table`
- **Columns:**
  - `id` (INT, AUTO_INCREMENT, PRIMARY KEY)
  - `data` (VARCHAR(255))
  - `created_at` (TIMESTAMP)
- **Sample Data:** 5 test records

### Test User (Auto-Generated)
- **Username:** `dosuser_YYYYMMDD_HHMMSS` (unique per run)
- **Password:** `DosPass123!`
- **Privileges:** SELECT on `dosdb_YYYYMMDD_HHMMSS.dos_test_table`
- **Host:** `%` (can connect from anywhere)

## Query Pattern

All queries execute the same SELECT statement:
```sql
SELECT * FROM dos_test_table;
```

This simple query is repeated:
- 1,001 times in runs 1-4 (baseline)
- 205,000 times in run 5 (DoS spike)

## Execution Timeline

```
Hour 0:  RUN 1 - 1,001 queries (baseline)
         ↓ Sleep 1 hour
Hour 1:  RUN 2 - 1,001 queries (baseline)
         ↓ Sleep 1 hour
Hour 2:  RUN 3 - 1,001 queries (baseline)
         ↓ Sleep 1 hour
Hour 3:  RUN 4 - 1,001 queries (baseline)
         ↓ Sleep 1 hour
Hour 4:  RUN 5 - 205,000 queries (SPIKE - DoS Attack)
         ↓ Complete
```

**Total Duration:** ~5 hours

## Run Breakdown

| Run | Queries | Sleep After | Type | Purpose |
|-----|---------|-------------|------|---------|
| 1 | 1,001 | 1 hour | Baseline | Establish normal pattern |
| 2 | 1,001 | 1 hour | Baseline | Reinforce normal pattern |
| 3 | 1,001 | 1 hour | Baseline | Confirm normal pattern |
| 4 | 1,001 | 1 hour | Baseline | Final baseline |
| **5** | **205,000** | - | **SPIKE** | **DoS Attack** |
| **Total** | **209,004** | - | - | **Complete** |

## Expected Duration

- **Run 1:** ~1-5 minutes + 1 hour sleep
- **Run 2:** ~1-5 minutes + 1 hour sleep
- **Run 3:** ~1-5 minutes + 1 hour sleep
- **Run 4:** ~1-5 minutes + 1 hour sleep
- **Run 5:** ~30-60 minutes (DoS spike)
- **Total:** ~5 hours

## Logs

The script creates detailed logs in the `logs/` directory:

### Log Files
- `dos_test_YYYYMMDD_HHMMSS.log` - Main execution log
- `dos_test_background_YYYYMMDD_HHMMSS.log` - Background mode log
- `dos_run1_YYYYMMDD_HHMMSS.log` - Run 1 detailed log
- `dos_run2_YYYYMMDD_HHMMSS.log` - Run 2 detailed log
- `dos_run3_YYYYMMDD_HHMMSS.log` - Run 3 detailed log
- `dos_run4_YYYYMMDD_HHMMSS.log` - Run 4 detailed log
- `dos_run5_YYYYMMDD_HHMMSS.log` - Run 5 detailed log (DoS spike)
- `dos_test_pid_YYYYMMDD_HHMMSS.txt` - Process ID file

### Log Contents
Each log includes:
- Timestamp for each operation
- Connection status
- Progress updates (every 1000 queries)
- Query execution results
- Sleep notifications
- Success/failure status
- Total duration

## Verification

After execution, verify the test ran successfully:

```sql
-- Check if databases exist
SHOW DATABASES LIKE 'dosdb_%';

-- Check if users exist
SELECT User, Host FROM mysql.user WHERE User LIKE 'dosuser_%';

-- Check specific database (replace with your timestamp)
USE dosdb_20231230_120000;
SHOW TABLES LIKE 'dos_test_table';

-- Check table data
SELECT * FROM dos_test_table;

-- Check query logs (if general log is enabled)
-- This will show the massive number of queries
```

## Monitoring and Detection

### What to Look For

After running this test, your monitoring systems should detect:

1. **Query Volume Spike**
   - Sudden increase from ~1K to 200K queries
   - Massive deviation from baseline

2. **Time-Based Pattern**
   - Consistent baseline over 4 hours
   - Sudden spike in hour 5

3. **User Behavior Anomaly**
   - Single user executing excessive queries
   - Unusual query pattern

4. **Resource Consumption**
   - Increased CPU usage during run 5
   - Increased network traffic
   - Increased connection count

5. **DoS Indicators**
   - Repetitive identical queries
   - Sustained high query rate
   - Potential service degradation

### ATA Case Detection

The pattern is specifically designed to trigger:
- **Denial of Service ATA Case**
- Baseline establishment (runs 1-4 over 4 hours)
- Anomaly spike detection (run 5)
- User behavior analytics alert
- Time-based anomaly detection

## Troubleshooting

### Issue: Permission Denied
```bash
chmod +x setup.sh run_dos_test.sh cleanup.sh
```

### Issue: MySQL Connection Failed
Check:
- Host and port are correct
- Password is correct
- MySQL server is running
- User has appropriate privileges

### Issue: Background Process Not Starting
```bash
# Check if nohup is available
which nohup

# Check logs directory permissions
ls -la logs/

# Verify script syntax
bash -n run_dos_test.sh
```

### Issue: Script Stops Unexpectedly
```bash
# Check the logs
tail -100 logs/dos_test_*.log

# Check for MySQL errors
tail -100 logs/dos_run*_*.log

# Verify MySQL is still running
mysql -h<host> -P<port> -u<user> -p<password> -e "SELECT 1;"
```

### Issue: Cannot Find Process
```bash
# Check PID file
cat logs/dos_test_pid_*.txt

# Check if process is running
ps -p <PID>

# Find all related processes
ps aux | grep -i dos
```

### Issue: Auto-Setup Failed
```bash
# Verify root access
mysql -h<host> -P<port> -uroot -p<password> -e "SELECT 1;"

# Check if database was created
mysql -h<host> -P<port> -uroot -p<password> -e "SHOW DATABASES LIKE 'dosdb_%';"

# Check logs for setup errors
tail -100 logs/dos_test_*.log
```

### Issue: User Cannot Connect
```bash
# Verify user was created (check logs for the exact username)
mysql -h<host> -P<port> -uroot -p<root_password> -e "SELECT User, Host FROM mysql.user WHERE User LIKE 'dosuser_%';"

# Test user connection (replace with actual username from logs)
mysql -h<host> -P<port> -udosuser_20231230_120000 -pDosPass123! -e "SELECT 1;"
```

### Issue: Slow Execution
This is expected for run 5 (200K queries). Factors affecting speed:
- Server performance
- Network latency
- Server load
- Query complexity

### Issue: Server Overload
If the server becomes unresponsive:
```bash
# Stop the test
pkill -f run_dos_test.sh

# Check server status
mysql -h<host> -P<port> -uroot -p<password> -e "SHOW PROCESSLIST;"

# Kill long-running queries if needed
mysql -h<host> -P<port> -uroot -p<password> -e "KILL <process_id>;"
```

## Security Notes

⚠️ **WARNING:** This script simulates a DoS attack!

- Only run in test environments
- Never run on production databases
- Can cause server performance degradation
- May trigger security alerts (this is intentional)
- Ensure you have permission to run security tests
- Monitor server resources during execution
- Be prepared to stop the test if needed
- Test in isolated environment first

## Example Output

### Foreground Mode
```
============================================================================
Denial of Service Test - Starting
============================================================================
Configuration:
  Host: localhost
  Port: 3306
  User: dosuser
  Pattern: 4 runs of 1001 queries (1 hour apart), then 1 run of 200001 queries
  Sleep Between Runs: 1 hour(s)
  Log Directory: /path/to/logs
  Main Log: /path/to/logs/dos_test_20231230_120000.log
============================================================================

Testing MySQL connection...
✓ MySQL connection successful

========================================================================
FIRST RUN (1 of 5)
========================================================================
RUN 1: Executing 1001 SELECT queries...
  Progress: 1000/1001 queries executed...
  ✓ RUN 1: 1001 queries completed in 15 seconds

Sleeping for 1 hour(s) before next run...
Next run (RUN 2) will start at: 2023-12-30 13:00:15

========================================================================
SECOND RUN (2 of 5)
========================================================================
RUN 2: Executing 1001 SELECT queries...
  Progress: 1000/1001 queries executed...
  ✓ RUN 2: 1001 queries completed in 14 seconds

Sleeping for 1 hour(s) before next run...
Next run (RUN 3) will start at: 2023-12-30 14:00:29

========================================================================
THIRD RUN (3 of 5)
========================================================================
RUN 3: Executing 1001 SELECT queries...
  Progress: 1000/1001 queries executed...
  ✓ RUN 3: 1001 queries completed in 15 seconds

Sleeping for 1 hour(s) before next run...
Next run (RUN 4) will start at: 2023-12-30 15:00:44

========================================================================
FOURTH RUN (4 of 5)
========================================================================
RUN 4: Executing 1001 SELECT queries...
  Progress: 1000/1001 queries executed...
  ✓ RUN 4: 1001 queries completed in 14 seconds

Sleeping for 1 hour(s) before SPIKE run...
SPIKE run (RUN 5 - 205000 queries) will start at: 2023-12-30 16:00:58

========================================================================
FIFTH RUN (5 of 5) - DENIAL OF SERVICE SPIKE: 205000 QUERIES
========================================================================
RUN 5: Executing 205000 SELECT queries...
  Progress: 1000/205000 queries executed...
  Progress: 2000/205000 queries executed...
  ...
  Progress: 204000/205000 queries executed...
  ✓ RUN 5: 205000 queries completed in 2920 seconds

============================================================================
Denial of Service Test Complete!
============================================================================
Total Runs: 5
Total Queries: 209004 (4004 normal + 205000 spike)
Total Duration: 4h 48m 25s
Logs Directory: /path/to/logs
Main Log: /path/to/logs/dos_test_20231230_120000.log
============================================================================

Next outlier run should detect Denial of Service ATA case
============================================================================
```

### Background Mode
```
============================================================================
Starting Denial of Service Test in Background
============================================================================
Host: localhost
Port: 3306
Background Log: /path/to/logs/dos_test_background_20231230_120000.log
============================================================================

The script is now running in the background.
To monitor progress:
  tail -f /path/to/logs/dos_test_background_20231230_120000.log

To check if it's still running:
  ps aux | grep run_dos_test.sh

To stop it:
  pkill -f run_dos_test.sh
============================================================================
Background Process ID: 12345
PID saved to: /path/to/logs/dos_test_pid_20231230_120000.txt

Script launched successfully!
```

## Integration with Monitoring

This script is designed to trigger alerts in:
- Database activity monitors
- Security information and event management (SIEM) systems
- Audit log analyzers
- Anomaly detection systems
- Advanced Threat Analytics (ATA) systems
- User Behavior Analytics (UBA) systems
- DoS detection systems

Look for:
- Sudden spike in query volume (run 5)
- Deviation from baseline pattern (runs 1-4)
- Time-based anomaly (consistent baseline then spike)
- Single user executing excessive queries
- Repetitive query patterns
- Resource consumption spikes
- DoS attack indicators

## Why This Pattern?

The pattern is specifically designed to:

1. **Establish Time-Based Baseline** (Runs 1-4 over 4 hours)
   - 4 runs of ~1K queries each
   - 1 hour apart to show consistent pattern
   - Creates normal behavior pattern over time
   - Allows anomaly detection to learn baseline

2. **Trigger DoS Detection** (Run 5)
   - 205K queries in single run
   - 205x increase from baseline
   - Clear anomaly spike
   - Triggers ATA DoS case

This pattern mimics real-world DoS attacks where:
- Attacker establishes normal pattern first
- Pattern is consistent over time
- Then launches massive attack
- Creates clear before/after pattern
- Time-based anomaly is more realistic

## Made with Bob
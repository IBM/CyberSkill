#!/bin/bash
# ============================================================================
# Script: generate_deletes.sh
# Purpose: Generate SQL file with 1000 individual DELETE commands
# Output: execute_1000_deletes.sql
# ============================================================================

OUTPUT_FILE="execute_1000_deletes.sql"

echo "Generating 1000 individual DELETE commands..."

# Start the SQL file
cat > "$OUTPUT_FILE" << 'EOF'
-- ============================================================================
-- Script: execute_1000_deletes.sql
-- Purpose: Execute 1000 individual DELETE commands on testdb database
-- Database: testdb
-- Generated with individual DELETE statements (no procedures)
-- ============================================================================

-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS testdb;
USE testdb;

-- ============================================================================
-- CREATE TABLE AND INSERT DATA
-- ============================================================================

-- Create a table to hold test data
CREATE TABLE IF NOT EXISTS delete_test_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    record_number INT NOT NULL,
    data VARCHAR(255),
    category VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_record_number (record_number),
    INDEX idx_category (category)
);

-- Insert 1000 records (to be deleted)
INSERT INTO delete_test_data (record_number, data, category) VALUES
EOF

# Generate 1000 INSERT statements
for i in $(seq 1 1000); do
    category=$((($i % 10) + 1))
    if [ $i -eq 1000 ]; then
        echo "(${i}, 'Test data for record ${i}', 'category_${category}');" >> "$OUTPUT_FILE"
    else
        echo "(${i}, 'Test data for record ${i}', 'category_${category}')," >> "$OUTPUT_FILE"
    fi
done

# Add separator
cat >> "$OUTPUT_FILE" << 'EOF'

-- Verify data inserted
SELECT COUNT(*) AS TotalRecords FROM delete_test_data;

-- ============================================================================
-- DELETE COMMANDS (1000 individual DELETE statements)
-- ============================================================================
-- Each DELETE removes one specific record by record_number
-- ============================================================================

EOF

# Generate 1000 DELETE statements
for i in $(seq 1 1000); do
    echo "DELETE FROM delete_test_data WHERE record_number = ${i};" >> "$OUTPUT_FILE"
done

# Add verification section
cat >> "$OUTPUT_FILE" << 'EOF'

-- ============================================================================
-- VERIFICATION
-- ============================================================================

-- Check remaining records
SELECT COUNT(*) AS RemainingRecords FROM delete_test_data;

-- Verify all records deleted
SELECT 
    CASE 
        WHEN COUNT(*) = 0 THEN 'SUCCESS: All 1000 records deleted'
        ELSE CONCAT('WARNING: ', COUNT(*), ' records still remain')
    END AS Result
FROM delete_test_data;

-- Check table still exists
SELECT 
    COUNT(*) AS TableExists
FROM information_schema.tables 
WHERE table_schema = 'testdb' 
AND table_name = 'delete_test_data';

SELECT 'All 1000 DELETE commands executed successfully!' AS FinalResult;

-- Made with Bob
EOF

echo "✓ Generated $OUTPUT_FILE with 1000 individual DELETE commands"
echo "✓ File size: $(wc -l < "$OUTPUT_FILE") lines"
echo "✓ Pattern: 1000 INSERT + 1000 DELETE statements"
echo "✓ Each DELETE removes one specific record"
echo ""
echo "To execute:"
echo "  mysql -h<host> -P<port> -uroot -p<password> < $OUTPUT_FILE"

# Made with Bob

#!/bin/bash
# ============================================================================
# Script: run_timed_deletes_background.sh
# Purpose: Run DELETE operations with time-based pattern in background
# Pattern: 50 deletes/hour for 4 hours, then 1000 deletes in 5th hour
# Note: Creates a new unique user and database each time it runs
# Usage: ./run_timed_deletes_background.sh <host> <port> <root_password>
# ============================================================================

# Check arguments (allow 3 or 4 arguments)
if [ "$#" -lt 3 ] || [ "$#" -gt 4 ]; then
    echo "Usage: $0 <host> <port> <root_password> [background|bg]"
    echo "Example: $0 localhost 3306 MyPassword123"
    echo "Example (background): $0 localhost 3306 MyPassword123 background"
    echo ""
    echo "Note: Script will automatically create a unique user and database"
    exit 1
fi

DB_HOST="$1"
DB_PORT="$2"
ROOT_PASSWORD="$3"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Configuration
SLEEP_HOURS=1
SLEEP_SECONDS=$((SLEEP_HOURS * 3600))
LOG_DIR="$SCRIPT_DIR/logs"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
MAIN_LOG="$LOG_DIR/timed_deletes_${TIMESTAMP}.log"
BACKGROUND_LOG="$LOG_DIR/timed_deletes_background_${TIMESTAMP}.log"

# Generate unique user and database names
DB_USER="delete_user_${TIMESTAMP}"
DB_USER_PASSWORD="DeletePass_${TIMESTAMP}_$(openssl rand -hex 4 2>/dev/null || echo 'default')"
DB_NAME="delete_db_${TIMESTAMP}"

# Create logs directory
mkdir -p "$LOG_DIR"

# Function to log messages
log_message() {
    local message="$1"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $message" | tee -a "$MAIN_LOG"
}

# Function to setup user and database
setup_user_and_database() {
    log_message "Setting up unique user and database..."
    log_message "  Database: $DB_NAME"
    log_message "  User: $DB_USER"
    
    # Create database
    log_message "  Creating database '$DB_NAME'..."
    mysql -h"$DB_HOST" -P"$DB_PORT" -uroot -p"$ROOT_PASSWORD" > /dev/null 2>&1 <<EOF
CREATE DATABASE \`$DB_NAME\`;
EOF
    
    if [ $? -eq 0 ]; then
        log_message "  ✓ Database '$DB_NAME' created successfully"
    else
        log_message "  ✗ Failed to create database '$DB_NAME'"
        return 1
    fi
    
    # Create user and grant all privileges
    log_message "  Creating user '$DB_USER' with all privileges..."
    mysql -h"$DB_HOST" -P"$DB_PORT" -uroot -p"$ROOT_PASSWORD" > /dev/null 2>&1 <<EOF
CREATE USER '$DB_USER'@'%' IDENTIFIED BY '$DB_USER_PASSWORD';
GRANT ALL PRIVILEGES ON \`$DB_NAME\`.* TO '$DB_USER'@'%';
FLUSH PRIVILEGES;
EOF
    
    if [ $? -eq 0 ]; then
        log_message "  ✓ User '$DB_USER' created with all privileges on '$DB_NAME'"
    else
        log_message "  ✗ Failed to create user or grant privileges"
        return 1
    fi
    
    # Test user connection
    log_message "  Testing user connection..."
    if mysql -h"$DB_HOST" -P"$DB_PORT" -u"$DB_USER" -p"$DB_USER_PASSWORD" "$DB_NAME" -e "SELECT 'User connection successful' AS Status;" > /dev/null 2>&1; then
        log_message "  ✓ User '$DB_USER' can connect to database '$DB_NAME'"
        return 0
    else
        log_message "  ✗ User connection test failed"
        return 1
    fi
}

# Function to execute DELETE commands
execute_deletes() {
    local num_deletes="$1"
    local hour_num="$2"
    local batch_log="$LOG_DIR/deletes_hour_${hour_num}_${TIMESTAMP}.log"
    
    log_message "Hour ${hour_num}: Executing ${num_deletes} DELETE commands as user '$DB_USER'..."
    
    # Create table if not exists and insert data
    mysql -h"$DB_HOST" -P"$DB_PORT" -u"$DB_USER" -p"$DB_USER_PASSWORD" "$DB_NAME" > "$batch_log" 2>&1 <<EOF
CREATE TABLE IF NOT EXISTS timed_delete_test (
    id INT AUTO_INCREMENT PRIMARY KEY,
    record_number INT NOT NULL,
    data VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_record_number (record_number)
);

-- Insert records if needed
INSERT IGNORE INTO timed_delete_test (record_number, data)
SELECT n, CONCAT('Data for record ', n)
FROM (
    SELECT a.N + b.N * 10 + c.N * 100 + d.N * 1000 + 1 AS n
    FROM
        (SELECT 0 AS N UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) a,
        (SELECT 0 AS N UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) b,
        (SELECT 0 AS N UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) c,
        (SELECT 0 AS N UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) d
) numbers
WHERE n <= 2000;

SELECT CONCAT('Records before delete: ', COUNT(*)) AS Status FROM timed_delete_test;
EOF

    # Generate and execute DELETE commands
    local start_record=$(( (hour_num - 1) * 50 + 1 ))
    
    if [ "$num_deletes" -eq 50 ]; then
        # Normal hour: 50 deletes
        for i in $(seq $start_record $((start_record + 49))); do
            mysql -h"$DB_HOST" -P"$DB_PORT" -u"$DB_USER" -p"$DB_USER_PASSWORD" "$DB_NAME" >> "$batch_log" 2>&1 <<EOF
DELETE FROM timed_delete_test WHERE record_number = $i;
EOF
        done
    else
        # Hour 5: 1000 deletes
        for i in $(seq 201 1200); do
            mysql -h"$DB_HOST" -P"$DB_PORT" -u"$DB_USER" -p"$DB_USER_PASSWORD" "$DB_NAME" >> "$batch_log" 2>&1 <<EOF
DELETE FROM timed_delete_test WHERE record_number = $i;
EOF
        done
    fi
    
    # Verify
    mysql -h"$DB_HOST" -P"$DB_PORT" -u"$DB_USER" -p"$DB_USER_PASSWORD" "$DB_NAME" >> "$batch_log" 2>&1 <<EOF
SELECT CONCAT('Records after delete: ', COUNT(*)) AS Status FROM timed_delete_test;
SELECT CONCAT('Hour ${hour_num}: ${num_deletes} DELETE commands completed') AS Result;
EOF
    
    if [ $? -eq 0 ]; then
        log_message "  ✓ Hour ${hour_num}: ${num_deletes} deletes completed successfully"
        return 0
    else
        log_message "  ✗ Hour ${hour_num}: DELETE operations failed (check $batch_log)"
        return 1
    fi
}

# Main execution function
main_execution() {
    log_message "============================================================================"
    log_message "Timed DELETE Operations - Background Execution"
    log_message "============================================================================"
    log_message "Configuration:"
    log_message "  Host: $DB_HOST"
    log_message "  Port: $DB_PORT"
    log_message "  Database: $DB_NAME (will be created)"
    log_message "  User: $DB_USER (will be created)"
    log_message "  Pattern: 50 deletes/hour for 4 hours, then 1000 deletes in hour 5"
    log_message "  Sleep Between Batches: $SLEEP_HOURS hour(s)"
    log_message "  Log Directory: $LOG_DIR"
    log_message "  Main Log: $MAIN_LOG"
    log_message "============================================================================"
    log_message ""
    
    # Test MySQL root connection
    log_message "Testing MySQL root connection..."
    if mysql -h"$DB_HOST" -P"$DB_PORT" -uroot -p"$ROOT_PASSWORD" -e "SELECT 'Connection successful' AS Status;" > /dev/null 2>&1; then
        log_message "✓ MySQL root connection successful"
    else
        log_message "✗ MySQL root connection failed!"
        log_message "Please check host, port, and root password."
        exit 1
    fi
    log_message ""
    
    # Setup user and database
    if ! setup_user_and_database; then
        log_message "✗ Failed to setup user and database"
        exit 1
    fi
    log_message ""
    
    # Start time
    local start_time=$(date +%s)
    
    # Hours 1-4: 50 deletes each
    for hour in $(seq 1 4); do
        log_message "========================================================================"
        log_message "Hour ${hour} of 5"
        log_message "========================================================================"
        
        execute_deletes 50 "$hour"
        
        if [ $hour -lt 4 ]; then
            log_message ""
            log_message "Sleeping for $SLEEP_HOURS hour(s) before next batch..."
            log_message "Next batch (Hour $((hour + 1))) will start at: $(date -d "+${SLEEP_HOURS} hours" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date -v+${SLEEP_HOURS}H '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo 'N/A')"
            log_message ""
            sleep $SLEEP_SECONDS
        fi
    done
    
    # Sleep before hour 5
    log_message ""
    log_message "Sleeping for $SLEEP_HOURS hour(s) before SPIKE batch..."
    log_message "SPIKE batch (Hour 5 - 1000 deletes) will start at: $(date -d "+${SLEEP_HOURS} hours" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date -v+${SLEEP_HOURS}H '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo 'N/A')"
    log_message ""
    sleep $SLEEP_SECONDS
    
    # Hour 5: 1000 deletes (SPIKE)
    log_message "========================================================================"
    log_message "Hour 5 of 5 - SPIKE: 1000 DELETE COMMANDS"
    log_message "========================================================================"
    
    execute_deletes 1000 5
    
    # End time and summary
    local end_time=$(date +%s)
    local duration=$((end_time - start_time))
    local hours=$((duration / 3600))
    local minutes=$(((duration % 3600) / 60))
    local seconds=$((duration % 60))
    
    log_message ""
    log_message "============================================================================"
    log_message "Timed DELETE Operations Complete!"
    log_message "============================================================================"
    log_message "Total Batches: 5"
    log_message "Total DELETEs: 1200 (200 normal + 1000 spike)"
    log_message "Total Duration: ${hours}h ${minutes}m ${seconds}s"
    log_message "Logs Directory: $LOG_DIR"
    log_message "Main Log: $MAIN_LOG"
    log_message "============================================================================"
}

# Check if we should run in background
if [ "$4" = "background" ] || [ "$4" = "bg" ]; then
    # Run in background with nohup
    echo "============================================================================"
    echo "Starting Timed DELETE Operations in Background"
    echo "============================================================================"
    echo "Host: $DB_HOST"
    echo "Port: $DB_PORT"
    echo "Database: $DB_NAME (will be created)"
    echo "User: $DB_USER (will be created)"
    echo "Background Log: $BACKGROUND_LOG"
    echo "============================================================================"
    echo ""
    echo "The script is now running in the background."
    echo "To monitor progress:"
    echo "  tail -f $BACKGROUND_LOG"
    echo ""
    echo "To check if it's still running:"
    echo "  ps aux | grep run_timed_deletes_background.sh"
    echo ""
    echo "To stop it:"
    echo "  pkill -f run_timed_deletes_background.sh"
    echo "============================================================================"
    
    # Export all variables for background execution
    export DB_HOST DB_PORT ROOT_PASSWORD DB_USER DB_USER_PASSWORD DB_NAME SCRIPT_DIR SLEEP_HOURS SLEEP_SECONDS LOG_DIR TIMESTAMP MAIN_LOG
    
    nohup bash -c '
        # Re-import variables
        DB_HOST="'"$DB_HOST"'"
        DB_PORT="'"$DB_PORT"'"
        ROOT_PASSWORD="'"$ROOT_PASSWORD"'"
        DB_USER="'"$DB_USER"'"
        DB_USER_PASSWORD="'"$DB_USER_PASSWORD"'"
        DB_NAME="'"$DB_NAME"'"
        SCRIPT_DIR="'"$SCRIPT_DIR"'"
        SLEEP_HOURS='"$SLEEP_HOURS"'
        SLEEP_SECONDS='"$SLEEP_SECONDS"'
        LOG_DIR="'"$LOG_DIR"'"
        TIMESTAMP="'"$TIMESTAMP"'"
        MAIN_LOG="'"$LOG_DIR"'/timed_deletes_'"$TIMESTAMP"'.log"
        
        # Define functions
        '"$(declare -f log_message)"'
        '"$(declare -f setup_user_and_database)"'
        '"$(declare -f execute_deletes)"'
        '"$(declare -f main_execution)"'
        
        # Run main execution
        main_execution
    ' > "$BACKGROUND_LOG" 2>&1 &
    
    BG_PID=$!
    echo "Background Process ID: $BG_PID"
    echo "$BG_PID" > "$LOG_DIR/timed_deletes_pid_${TIMESTAMP}.txt"
    echo ""
    echo "Script launched successfully!"
    echo "PID saved to: $LOG_DIR/timed_deletes_pid_${TIMESTAMP}.txt"
else
    # Run in foreground
    main_execution
fi

# Made with Bob

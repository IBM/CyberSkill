/*  Notification [Common Notification]
*
*	Author(s): Jason Flood/John Clarke
*  	Licence: Apache 2
*  
*   
*/


package metrics.thejasonengine.com;

import io.vertx.core.Vertx;
import io.vertx.core.metrics.MetricsOptions;
import io.vertx.micrometer.backends.BackendRegistries;
import io.vertx.micrometer.MicrometerMetricsOptions;
import io.vertx.core.VertxOptions;

public class Telemetary {

	public static void getMetrics()
	{
		
	}
	
}



/*  Notification [Common Notification]
*
*	Author(s): Jason Flood/John Clarke
*  	Licence: Apache 2
*  
*   
*/

package authentication.thejasonengine.com;

import io.vertx.ext.web.Router;
import authentication.thejasonengine.com.AuthHandler;

public class AuthRouter {

    public static void setup(Router router) {
   
    }
}